#!/bin/bash
export TIMEFORMAT=$'\nreal\t%3R\nuser\t%3U\nsys\t%3S'
export TESTSPATH='tests.'
export DMCSPATH='../../build/src'
$DMCSPATH/dmcsd --context=1 --port=5001 --kb=$TESTSPATH/tree-7-8-4-4-a-1.lp --br=$TESTSPATH/tree-7-8-4-4-a-1.br --topology=$TESTSPATH/tree-7-8-4-4-a.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=2 --port=5002 --kb=$TESTSPATH/tree-7-8-4-4-a-2.lp --br=$TESTSPATH/tree-7-8-4-4-a-2.br --topology=$TESTSPATH/tree-7-8-4-4-a.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=3 --port=5003 --kb=$TESTSPATH/tree-7-8-4-4-a-3.lp --br=$TESTSPATH/tree-7-8-4-4-a-3.br --topology=$TESTSPATH/tree-7-8-4-4-a.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=4 --port=5004 --kb=$TESTSPATH/tree-7-8-4-4-a-4.lp --br=$TESTSPATH/tree-7-8-4-4-a-4.br --topology=$TESTSPATH/tree-7-8-4-4-a.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=5 --port=5005 --kb=$TESTSPATH/tree-7-8-4-4-a-5.lp --br=$TESTSPATH/tree-7-8-4-4-a-5.br --topology=$TESTSPATH/tree-7-8-4-4-a.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=6 --port=5006 --kb=$TESTSPATH/tree-7-8-4-4-a-6.lp --br=$TESTSPATH/tree-7-8-4-4-a-6.br --topology=$TESTSPATH/tree-7-8-4-4-a.top >/dev/null 2>&1 &
$DMCSPATH/dmcsd --context=7 --port=5007 --kb=$TESTSPATH/tree-7-8-4-4-a-7.lp --br=$TESTSPATH/tree-7-8-4-4-a-7.br --topology=$TESTSPATH/tree-7-8-4-4-a.top >/dev/null 2>&1 &
/usr/bin/time --portability -o tree-7-8-4-4-a-dmcs-time.log $DMCSPATH/dmcsc --hostname=localhost --port=5001 --system-size=7 --query-variables="{0 1 2 3 4 5 6 7 8} {0 4} {0 2} {0 1 8} {0 4} {0 5 7} {0 4} " > tree-7-8-4-4-a-dmcs.log 2> tree-7-8-4-4-a-dmcs-err.log
killall dmcsd
