#!/bin/bash
export TIMEFORMAT=$'\nreal\t%3R\nuser\t%3U\nsys\t%3S'
export TIMEOUT=600
export TESTPATH='.'
export DMCSPATH='../../../../../build/src'
killall new_dmcsd
killall new_dmcsm
sleep 5
$DMCSPATH/new_dmcsm --port=4999 --system-size=31 &
sleep 5
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-0.br --context=0 --kb=$TESTPATH/tree-0.lp --manager=localhost:4999 --packsize=0 --port=5000 --queryplan=$TESTPATH/tree-0.qp --returnplan=$TESTPATH/tree-0.rp --system-size=31  >tree-0.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-1.br --context=1 --kb=$TESTPATH/tree-1.lp --manager=localhost:4999 --packsize=0 --port=5001 --queryplan=$TESTPATH/tree-1.qp --returnplan=$TESTPATH/tree-1.rp --system-size=31  >tree-1.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-2.br --context=2 --kb=$TESTPATH/tree-2.lp --manager=localhost:4999 --packsize=0 --port=5002 --queryplan=$TESTPATH/tree-2.qp --returnplan=$TESTPATH/tree-2.rp --system-size=31  >tree-2.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-3.br --context=3 --kb=$TESTPATH/tree-3.lp --manager=localhost:4999 --packsize=0 --port=5003 --queryplan=$TESTPATH/tree-3.qp --returnplan=$TESTPATH/tree-3.rp --system-size=31  >tree-3.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-4.br --context=4 --kb=$TESTPATH/tree-4.lp --manager=localhost:4999 --packsize=0 --port=5004 --queryplan=$TESTPATH/tree-4.qp --returnplan=$TESTPATH/tree-4.rp --system-size=31  >tree-4.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-5.br --context=5 --kb=$TESTPATH/tree-5.lp --manager=localhost:4999 --packsize=0 --port=5005 --queryplan=$TESTPATH/tree-5.qp --returnplan=$TESTPATH/tree-5.rp --system-size=31  >tree-5.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-6.br --context=6 --kb=$TESTPATH/tree-6.lp --manager=localhost:4999 --packsize=0 --port=5006 --queryplan=$TESTPATH/tree-6.qp --returnplan=$TESTPATH/tree-6.rp --system-size=31  >tree-6.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-7.br --context=7 --kb=$TESTPATH/tree-7.lp --manager=localhost:4999 --packsize=0 --port=5007 --queryplan=$TESTPATH/tree-7.qp --returnplan=$TESTPATH/tree-7.rp --system-size=31  >tree-7.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-8.br --context=8 --kb=$TESTPATH/tree-8.lp --manager=localhost:4999 --packsize=0 --port=5008 --queryplan=$TESTPATH/tree-8.qp --returnplan=$TESTPATH/tree-8.rp --system-size=31  >tree-8.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-9.br --context=9 --kb=$TESTPATH/tree-9.lp --manager=localhost:4999 --packsize=0 --port=5009 --queryplan=$TESTPATH/tree-9.qp --returnplan=$TESTPATH/tree-9.rp --system-size=31  >tree-9.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-10.br --context=10 --kb=$TESTPATH/tree-10.lp --manager=localhost:4999 --packsize=0 --port=5010 --queryplan=$TESTPATH/tree-10.qp --returnplan=$TESTPATH/tree-10.rp --system-size=31  >tree-10.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-11.br --context=11 --kb=$TESTPATH/tree-11.lp --manager=localhost:4999 --packsize=0 --port=5011 --queryplan=$TESTPATH/tree-11.qp --returnplan=$TESTPATH/tree-11.rp --system-size=31  >tree-11.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-12.br --context=12 --kb=$TESTPATH/tree-12.lp --manager=localhost:4999 --packsize=0 --port=5012 --queryplan=$TESTPATH/tree-12.qp --returnplan=$TESTPATH/tree-12.rp --system-size=31  >tree-12.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-13.br --context=13 --kb=$TESTPATH/tree-13.lp --manager=localhost:4999 --packsize=0 --port=5013 --queryplan=$TESTPATH/tree-13.qp --returnplan=$TESTPATH/tree-13.rp --system-size=31  >tree-13.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-14.br --context=14 --kb=$TESTPATH/tree-14.lp --manager=localhost:4999 --packsize=0 --port=5014 --queryplan=$TESTPATH/tree-14.qp --returnplan=$TESTPATH/tree-14.rp --system-size=31  >tree-14.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-15.br --context=15 --kb=$TESTPATH/tree-15.lp --manager=localhost:4999 --packsize=0 --port=5015 --queryplan=$TESTPATH/tree-15.qp --returnplan=$TESTPATH/tree-15.rp --system-size=31  >tree-15.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-16.br --context=16 --kb=$TESTPATH/tree-16.lp --manager=localhost:4999 --packsize=0 --port=5016 --queryplan=$TESTPATH/tree-16.qp --returnplan=$TESTPATH/tree-16.rp --system-size=31  >tree-16.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-17.br --context=17 --kb=$TESTPATH/tree-17.lp --manager=localhost:4999 --packsize=0 --port=5017 --queryplan=$TESTPATH/tree-17.qp --returnplan=$TESTPATH/tree-17.rp --system-size=31  >tree-17.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-18.br --context=18 --kb=$TESTPATH/tree-18.lp --manager=localhost:4999 --packsize=0 --port=5018 --queryplan=$TESTPATH/tree-18.qp --returnplan=$TESTPATH/tree-18.rp --system-size=31  >tree-18.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-19.br --context=19 --kb=$TESTPATH/tree-19.lp --manager=localhost:4999 --packsize=0 --port=5019 --queryplan=$TESTPATH/tree-19.qp --returnplan=$TESTPATH/tree-19.rp --system-size=31  >tree-19.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-20.br --context=20 --kb=$TESTPATH/tree-20.lp --manager=localhost:4999 --packsize=0 --port=5020 --queryplan=$TESTPATH/tree-20.qp --returnplan=$TESTPATH/tree-20.rp --system-size=31  >tree-20.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-21.br --context=21 --kb=$TESTPATH/tree-21.lp --manager=localhost:4999 --packsize=0 --port=5021 --queryplan=$TESTPATH/tree-21.qp --returnplan=$TESTPATH/tree-21.rp --system-size=31  >tree-21.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-22.br --context=22 --kb=$TESTPATH/tree-22.lp --manager=localhost:4999 --packsize=0 --port=5022 --queryplan=$TESTPATH/tree-22.qp --returnplan=$TESTPATH/tree-22.rp --system-size=31  >tree-22.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-23.br --context=23 --kb=$TESTPATH/tree-23.lp --manager=localhost:4999 --packsize=0 --port=5023 --queryplan=$TESTPATH/tree-23.qp --returnplan=$TESTPATH/tree-23.rp --system-size=31  >tree-23.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-24.br --context=24 --kb=$TESTPATH/tree-24.lp --manager=localhost:4999 --packsize=0 --port=5024 --queryplan=$TESTPATH/tree-24.qp --returnplan=$TESTPATH/tree-24.rp --system-size=31  >tree-24.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-25.br --context=25 --kb=$TESTPATH/tree-25.lp --manager=localhost:4999 --packsize=0 --port=5025 --queryplan=$TESTPATH/tree-25.qp --returnplan=$TESTPATH/tree-25.rp --system-size=31  >tree-25.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-26.br --context=26 --kb=$TESTPATH/tree-26.lp --manager=localhost:4999 --packsize=0 --port=5026 --queryplan=$TESTPATH/tree-26.qp --returnplan=$TESTPATH/tree-26.rp --system-size=31  >tree-26.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-27.br --context=27 --kb=$TESTPATH/tree-27.lp --manager=localhost:4999 --packsize=0 --port=5027 --queryplan=$TESTPATH/tree-27.qp --returnplan=$TESTPATH/tree-27.rp --system-size=31  >tree-27.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-28.br --context=28 --kb=$TESTPATH/tree-28.lp --manager=localhost:4999 --packsize=0 --port=5028 --queryplan=$TESTPATH/tree-28.qp --returnplan=$TESTPATH/tree-28.rp --system-size=31  >tree-28.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-29.br --context=29 --kb=$TESTPATH/tree-29.lp --manager=localhost:4999 --packsize=0 --port=5029 --queryplan=$TESTPATH/tree-29.qp --returnplan=$TESTPATH/tree-29.rp --system-size=31  >tree-29.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-30.br --context=30 --kb=$TESTPATH/tree-30.lp --manager=localhost:4999 --packsize=0 --port=5030 --queryplan=$TESTPATH/tree-30.qp --returnplan=$TESTPATH/tree-30.rp --system-size=31  >tree-30.log 2>&1 &
sleep 2
sleep 62
/usr/bin/time --verbose -o tree-time.log /usr/bin/timeout -k 20 $TIMEOUT $DMCSPATH/new_dmcsc --hostname=localhost --port=5000 --root=0 --signature=$TESTPATH/client.qp --belief-state-size=20 --k1=0 --k2=0 --loop=1 > tree.log 2> tree-err.log
