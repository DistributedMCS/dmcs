#!/bin/bash
export TIMEFORMAT=$'\nreal\t%3R\nuser\t%3U\nsys\t%3S'
export TIMEOUT=600
export TESTPATH='.'
export DMCSPATH='../../../../../build/src'
killall new_dmcsd
killall new_dmcsm
sleep 5
$DMCSPATH/new_dmcsm --port=4999 --system-size=100 &
sleep 5
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-0.br --context=0 --kb=$TESTPATH/tree-0.lp --manager=localhost:4999 --packsize=0 --port=5000 --queryplan=$TESTPATH/tree-0.qp --returnplan=$TESTPATH/tree-0.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-1.br --context=1 --kb=$TESTPATH/tree-1.lp --manager=localhost:4999 --packsize=0 --port=5001 --queryplan=$TESTPATH/tree-1.qp --returnplan=$TESTPATH/tree-1.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-2.br --context=2 --kb=$TESTPATH/tree-2.lp --manager=localhost:4999 --packsize=0 --port=5002 --queryplan=$TESTPATH/tree-2.qp --returnplan=$TESTPATH/tree-2.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-3.br --context=3 --kb=$TESTPATH/tree-3.lp --manager=localhost:4999 --packsize=0 --port=5003 --queryplan=$TESTPATH/tree-3.qp --returnplan=$TESTPATH/tree-3.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-4.br --context=4 --kb=$TESTPATH/tree-4.lp --manager=localhost:4999 --packsize=0 --port=5004 --queryplan=$TESTPATH/tree-4.qp --returnplan=$TESTPATH/tree-4.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-5.br --context=5 --kb=$TESTPATH/tree-5.lp --manager=localhost:4999 --packsize=0 --port=5005 --queryplan=$TESTPATH/tree-5.qp --returnplan=$TESTPATH/tree-5.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-6.br --context=6 --kb=$TESTPATH/tree-6.lp --manager=localhost:4999 --packsize=0 --port=5006 --queryplan=$TESTPATH/tree-6.qp --returnplan=$TESTPATH/tree-6.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-7.br --context=7 --kb=$TESTPATH/tree-7.lp --manager=localhost:4999 --packsize=0 --port=5007 --queryplan=$TESTPATH/tree-7.qp --returnplan=$TESTPATH/tree-7.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-8.br --context=8 --kb=$TESTPATH/tree-8.lp --manager=localhost:4999 --packsize=0 --port=5008 --queryplan=$TESTPATH/tree-8.qp --returnplan=$TESTPATH/tree-8.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-9.br --context=9 --kb=$TESTPATH/tree-9.lp --manager=localhost:4999 --packsize=0 --port=5009 --queryplan=$TESTPATH/tree-9.qp --returnplan=$TESTPATH/tree-9.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-10.br --context=10 --kb=$TESTPATH/tree-10.lp --manager=localhost:4999 --packsize=0 --port=5010 --queryplan=$TESTPATH/tree-10.qp --returnplan=$TESTPATH/tree-10.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-11.br --context=11 --kb=$TESTPATH/tree-11.lp --manager=localhost:4999 --packsize=0 --port=5011 --queryplan=$TESTPATH/tree-11.qp --returnplan=$TESTPATH/tree-11.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-12.br --context=12 --kb=$TESTPATH/tree-12.lp --manager=localhost:4999 --packsize=0 --port=5012 --queryplan=$TESTPATH/tree-12.qp --returnplan=$TESTPATH/tree-12.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-13.br --context=13 --kb=$TESTPATH/tree-13.lp --manager=localhost:4999 --packsize=0 --port=5013 --queryplan=$TESTPATH/tree-13.qp --returnplan=$TESTPATH/tree-13.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-14.br --context=14 --kb=$TESTPATH/tree-14.lp --manager=localhost:4999 --packsize=0 --port=5014 --queryplan=$TESTPATH/tree-14.qp --returnplan=$TESTPATH/tree-14.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-15.br --context=15 --kb=$TESTPATH/tree-15.lp --manager=localhost:4999 --packsize=0 --port=5015 --queryplan=$TESTPATH/tree-15.qp --returnplan=$TESTPATH/tree-15.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-16.br --context=16 --kb=$TESTPATH/tree-16.lp --manager=localhost:4999 --packsize=0 --port=5016 --queryplan=$TESTPATH/tree-16.qp --returnplan=$TESTPATH/tree-16.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-17.br --context=17 --kb=$TESTPATH/tree-17.lp --manager=localhost:4999 --packsize=0 --port=5017 --queryplan=$TESTPATH/tree-17.qp --returnplan=$TESTPATH/tree-17.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-18.br --context=18 --kb=$TESTPATH/tree-18.lp --manager=localhost:4999 --packsize=0 --port=5018 --queryplan=$TESTPATH/tree-18.qp --returnplan=$TESTPATH/tree-18.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-19.br --context=19 --kb=$TESTPATH/tree-19.lp --manager=localhost:4999 --packsize=0 --port=5019 --queryplan=$TESTPATH/tree-19.qp --returnplan=$TESTPATH/tree-19.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-20.br --context=20 --kb=$TESTPATH/tree-20.lp --manager=localhost:4999 --packsize=0 --port=5020 --queryplan=$TESTPATH/tree-20.qp --returnplan=$TESTPATH/tree-20.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-21.br --context=21 --kb=$TESTPATH/tree-21.lp --manager=localhost:4999 --packsize=0 --port=5021 --queryplan=$TESTPATH/tree-21.qp --returnplan=$TESTPATH/tree-21.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-22.br --context=22 --kb=$TESTPATH/tree-22.lp --manager=localhost:4999 --packsize=0 --port=5022 --queryplan=$TESTPATH/tree-22.qp --returnplan=$TESTPATH/tree-22.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-23.br --context=23 --kb=$TESTPATH/tree-23.lp --manager=localhost:4999 --packsize=0 --port=5023 --queryplan=$TESTPATH/tree-23.qp --returnplan=$TESTPATH/tree-23.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-24.br --context=24 --kb=$TESTPATH/tree-24.lp --manager=localhost:4999 --packsize=0 --port=5024 --queryplan=$TESTPATH/tree-24.qp --returnplan=$TESTPATH/tree-24.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-25.br --context=25 --kb=$TESTPATH/tree-25.lp --manager=localhost:4999 --packsize=0 --port=5025 --queryplan=$TESTPATH/tree-25.qp --returnplan=$TESTPATH/tree-25.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-26.br --context=26 --kb=$TESTPATH/tree-26.lp --manager=localhost:4999 --packsize=0 --port=5026 --queryplan=$TESTPATH/tree-26.qp --returnplan=$TESTPATH/tree-26.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-27.br --context=27 --kb=$TESTPATH/tree-27.lp --manager=localhost:4999 --packsize=0 --port=5027 --queryplan=$TESTPATH/tree-27.qp --returnplan=$TESTPATH/tree-27.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-28.br --context=28 --kb=$TESTPATH/tree-28.lp --manager=localhost:4999 --packsize=0 --port=5028 --queryplan=$TESTPATH/tree-28.qp --returnplan=$TESTPATH/tree-28.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-29.br --context=29 --kb=$TESTPATH/tree-29.lp --manager=localhost:4999 --packsize=0 --port=5029 --queryplan=$TESTPATH/tree-29.qp --returnplan=$TESTPATH/tree-29.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-30.br --context=30 --kb=$TESTPATH/tree-30.lp --manager=localhost:4999 --packsize=0 --port=5030 --queryplan=$TESTPATH/tree-30.qp --returnplan=$TESTPATH/tree-30.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-31.br --context=31 --kb=$TESTPATH/tree-31.lp --manager=localhost:4999 --packsize=0 --port=5031 --queryplan=$TESTPATH/tree-31.qp --returnplan=$TESTPATH/tree-31.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-32.br --context=32 --kb=$TESTPATH/tree-32.lp --manager=localhost:4999 --packsize=0 --port=5032 --queryplan=$TESTPATH/tree-32.qp --returnplan=$TESTPATH/tree-32.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-33.br --context=33 --kb=$TESTPATH/tree-33.lp --manager=localhost:4999 --packsize=0 --port=5033 --queryplan=$TESTPATH/tree-33.qp --returnplan=$TESTPATH/tree-33.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-34.br --context=34 --kb=$TESTPATH/tree-34.lp --manager=localhost:4999 --packsize=0 --port=5034 --queryplan=$TESTPATH/tree-34.qp --returnplan=$TESTPATH/tree-34.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-35.br --context=35 --kb=$TESTPATH/tree-35.lp --manager=localhost:4999 --packsize=0 --port=5035 --queryplan=$TESTPATH/tree-35.qp --returnplan=$TESTPATH/tree-35.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-36.br --context=36 --kb=$TESTPATH/tree-36.lp --manager=localhost:4999 --packsize=0 --port=5036 --queryplan=$TESTPATH/tree-36.qp --returnplan=$TESTPATH/tree-36.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-37.br --context=37 --kb=$TESTPATH/tree-37.lp --manager=localhost:4999 --packsize=0 --port=5037 --queryplan=$TESTPATH/tree-37.qp --returnplan=$TESTPATH/tree-37.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-38.br --context=38 --kb=$TESTPATH/tree-38.lp --manager=localhost:4999 --packsize=0 --port=5038 --queryplan=$TESTPATH/tree-38.qp --returnplan=$TESTPATH/tree-38.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-39.br --context=39 --kb=$TESTPATH/tree-39.lp --manager=localhost:4999 --packsize=0 --port=5039 --queryplan=$TESTPATH/tree-39.qp --returnplan=$TESTPATH/tree-39.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-40.br --context=40 --kb=$TESTPATH/tree-40.lp --manager=localhost:4999 --packsize=0 --port=5040 --queryplan=$TESTPATH/tree-40.qp --returnplan=$TESTPATH/tree-40.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-41.br --context=41 --kb=$TESTPATH/tree-41.lp --manager=localhost:4999 --packsize=0 --port=5041 --queryplan=$TESTPATH/tree-41.qp --returnplan=$TESTPATH/tree-41.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-42.br --context=42 --kb=$TESTPATH/tree-42.lp --manager=localhost:4999 --packsize=0 --port=5042 --queryplan=$TESTPATH/tree-42.qp --returnplan=$TESTPATH/tree-42.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-43.br --context=43 --kb=$TESTPATH/tree-43.lp --manager=localhost:4999 --packsize=0 --port=5043 --queryplan=$TESTPATH/tree-43.qp --returnplan=$TESTPATH/tree-43.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-44.br --context=44 --kb=$TESTPATH/tree-44.lp --manager=localhost:4999 --packsize=0 --port=5044 --queryplan=$TESTPATH/tree-44.qp --returnplan=$TESTPATH/tree-44.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-45.br --context=45 --kb=$TESTPATH/tree-45.lp --manager=localhost:4999 --packsize=0 --port=5045 --queryplan=$TESTPATH/tree-45.qp --returnplan=$TESTPATH/tree-45.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-46.br --context=46 --kb=$TESTPATH/tree-46.lp --manager=localhost:4999 --packsize=0 --port=5046 --queryplan=$TESTPATH/tree-46.qp --returnplan=$TESTPATH/tree-46.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-47.br --context=47 --kb=$TESTPATH/tree-47.lp --manager=localhost:4999 --packsize=0 --port=5047 --queryplan=$TESTPATH/tree-47.qp --returnplan=$TESTPATH/tree-47.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-48.br --context=48 --kb=$TESTPATH/tree-48.lp --manager=localhost:4999 --packsize=0 --port=5048 --queryplan=$TESTPATH/tree-48.qp --returnplan=$TESTPATH/tree-48.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-49.br --context=49 --kb=$TESTPATH/tree-49.lp --manager=localhost:4999 --packsize=0 --port=5049 --queryplan=$TESTPATH/tree-49.qp --returnplan=$TESTPATH/tree-49.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-50.br --context=50 --kb=$TESTPATH/tree-50.lp --manager=localhost:4999 --packsize=0 --port=5050 --queryplan=$TESTPATH/tree-50.qp --returnplan=$TESTPATH/tree-50.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-51.br --context=51 --kb=$TESTPATH/tree-51.lp --manager=localhost:4999 --packsize=0 --port=5051 --queryplan=$TESTPATH/tree-51.qp --returnplan=$TESTPATH/tree-51.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-52.br --context=52 --kb=$TESTPATH/tree-52.lp --manager=localhost:4999 --packsize=0 --port=5052 --queryplan=$TESTPATH/tree-52.qp --returnplan=$TESTPATH/tree-52.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-53.br --context=53 --kb=$TESTPATH/tree-53.lp --manager=localhost:4999 --packsize=0 --port=5053 --queryplan=$TESTPATH/tree-53.qp --returnplan=$TESTPATH/tree-53.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-54.br --context=54 --kb=$TESTPATH/tree-54.lp --manager=localhost:4999 --packsize=0 --port=5054 --queryplan=$TESTPATH/tree-54.qp --returnplan=$TESTPATH/tree-54.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-55.br --context=55 --kb=$TESTPATH/tree-55.lp --manager=localhost:4999 --packsize=0 --port=5055 --queryplan=$TESTPATH/tree-55.qp --returnplan=$TESTPATH/tree-55.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-56.br --context=56 --kb=$TESTPATH/tree-56.lp --manager=localhost:4999 --packsize=0 --port=5056 --queryplan=$TESTPATH/tree-56.qp --returnplan=$TESTPATH/tree-56.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-57.br --context=57 --kb=$TESTPATH/tree-57.lp --manager=localhost:4999 --packsize=0 --port=5057 --queryplan=$TESTPATH/tree-57.qp --returnplan=$TESTPATH/tree-57.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-58.br --context=58 --kb=$TESTPATH/tree-58.lp --manager=localhost:4999 --packsize=0 --port=5058 --queryplan=$TESTPATH/tree-58.qp --returnplan=$TESTPATH/tree-58.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-59.br --context=59 --kb=$TESTPATH/tree-59.lp --manager=localhost:4999 --packsize=0 --port=5059 --queryplan=$TESTPATH/tree-59.qp --returnplan=$TESTPATH/tree-59.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-60.br --context=60 --kb=$TESTPATH/tree-60.lp --manager=localhost:4999 --packsize=0 --port=5060 --queryplan=$TESTPATH/tree-60.qp --returnplan=$TESTPATH/tree-60.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-61.br --context=61 --kb=$TESTPATH/tree-61.lp --manager=localhost:4999 --packsize=0 --port=5061 --queryplan=$TESTPATH/tree-61.qp --returnplan=$TESTPATH/tree-61.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-62.br --context=62 --kb=$TESTPATH/tree-62.lp --manager=localhost:4999 --packsize=0 --port=5062 --queryplan=$TESTPATH/tree-62.qp --returnplan=$TESTPATH/tree-62.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-63.br --context=63 --kb=$TESTPATH/tree-63.lp --manager=localhost:4999 --packsize=0 --port=5063 --queryplan=$TESTPATH/tree-63.qp --returnplan=$TESTPATH/tree-63.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-64.br --context=64 --kb=$TESTPATH/tree-64.lp --manager=localhost:4999 --packsize=0 --port=5064 --queryplan=$TESTPATH/tree-64.qp --returnplan=$TESTPATH/tree-64.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-65.br --context=65 --kb=$TESTPATH/tree-65.lp --manager=localhost:4999 --packsize=0 --port=5065 --queryplan=$TESTPATH/tree-65.qp --returnplan=$TESTPATH/tree-65.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-66.br --context=66 --kb=$TESTPATH/tree-66.lp --manager=localhost:4999 --packsize=0 --port=5066 --queryplan=$TESTPATH/tree-66.qp --returnplan=$TESTPATH/tree-66.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-67.br --context=67 --kb=$TESTPATH/tree-67.lp --manager=localhost:4999 --packsize=0 --port=5067 --queryplan=$TESTPATH/tree-67.qp --returnplan=$TESTPATH/tree-67.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-68.br --context=68 --kb=$TESTPATH/tree-68.lp --manager=localhost:4999 --packsize=0 --port=5068 --queryplan=$TESTPATH/tree-68.qp --returnplan=$TESTPATH/tree-68.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-69.br --context=69 --kb=$TESTPATH/tree-69.lp --manager=localhost:4999 --packsize=0 --port=5069 --queryplan=$TESTPATH/tree-69.qp --returnplan=$TESTPATH/tree-69.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-70.br --context=70 --kb=$TESTPATH/tree-70.lp --manager=localhost:4999 --packsize=0 --port=5070 --queryplan=$TESTPATH/tree-70.qp --returnplan=$TESTPATH/tree-70.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-71.br --context=71 --kb=$TESTPATH/tree-71.lp --manager=localhost:4999 --packsize=0 --port=5071 --queryplan=$TESTPATH/tree-71.qp --returnplan=$TESTPATH/tree-71.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-72.br --context=72 --kb=$TESTPATH/tree-72.lp --manager=localhost:4999 --packsize=0 --port=5072 --queryplan=$TESTPATH/tree-72.qp --returnplan=$TESTPATH/tree-72.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-73.br --context=73 --kb=$TESTPATH/tree-73.lp --manager=localhost:4999 --packsize=0 --port=5073 --queryplan=$TESTPATH/tree-73.qp --returnplan=$TESTPATH/tree-73.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-74.br --context=74 --kb=$TESTPATH/tree-74.lp --manager=localhost:4999 --packsize=0 --port=5074 --queryplan=$TESTPATH/tree-74.qp --returnplan=$TESTPATH/tree-74.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-75.br --context=75 --kb=$TESTPATH/tree-75.lp --manager=localhost:4999 --packsize=0 --port=5075 --queryplan=$TESTPATH/tree-75.qp --returnplan=$TESTPATH/tree-75.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-76.br --context=76 --kb=$TESTPATH/tree-76.lp --manager=localhost:4999 --packsize=0 --port=5076 --queryplan=$TESTPATH/tree-76.qp --returnplan=$TESTPATH/tree-76.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-77.br --context=77 --kb=$TESTPATH/tree-77.lp --manager=localhost:4999 --packsize=0 --port=5077 --queryplan=$TESTPATH/tree-77.qp --returnplan=$TESTPATH/tree-77.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-78.br --context=78 --kb=$TESTPATH/tree-78.lp --manager=localhost:4999 --packsize=0 --port=5078 --queryplan=$TESTPATH/tree-78.qp --returnplan=$TESTPATH/tree-78.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-79.br --context=79 --kb=$TESTPATH/tree-79.lp --manager=localhost:4999 --packsize=0 --port=5079 --queryplan=$TESTPATH/tree-79.qp --returnplan=$TESTPATH/tree-79.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-80.br --context=80 --kb=$TESTPATH/tree-80.lp --manager=localhost:4999 --packsize=0 --port=5080 --queryplan=$TESTPATH/tree-80.qp --returnplan=$TESTPATH/tree-80.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-81.br --context=81 --kb=$TESTPATH/tree-81.lp --manager=localhost:4999 --packsize=0 --port=5081 --queryplan=$TESTPATH/tree-81.qp --returnplan=$TESTPATH/tree-81.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-82.br --context=82 --kb=$TESTPATH/tree-82.lp --manager=localhost:4999 --packsize=0 --port=5082 --queryplan=$TESTPATH/tree-82.qp --returnplan=$TESTPATH/tree-82.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-83.br --context=83 --kb=$TESTPATH/tree-83.lp --manager=localhost:4999 --packsize=0 --port=5083 --queryplan=$TESTPATH/tree-83.qp --returnplan=$TESTPATH/tree-83.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-84.br --context=84 --kb=$TESTPATH/tree-84.lp --manager=localhost:4999 --packsize=0 --port=5084 --queryplan=$TESTPATH/tree-84.qp --returnplan=$TESTPATH/tree-84.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-85.br --context=85 --kb=$TESTPATH/tree-85.lp --manager=localhost:4999 --packsize=0 --port=5085 --queryplan=$TESTPATH/tree-85.qp --returnplan=$TESTPATH/tree-85.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-86.br --context=86 --kb=$TESTPATH/tree-86.lp --manager=localhost:4999 --packsize=0 --port=5086 --queryplan=$TESTPATH/tree-86.qp --returnplan=$TESTPATH/tree-86.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-87.br --context=87 --kb=$TESTPATH/tree-87.lp --manager=localhost:4999 --packsize=0 --port=5087 --queryplan=$TESTPATH/tree-87.qp --returnplan=$TESTPATH/tree-87.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-88.br --context=88 --kb=$TESTPATH/tree-88.lp --manager=localhost:4999 --packsize=0 --port=5088 --queryplan=$TESTPATH/tree-88.qp --returnplan=$TESTPATH/tree-88.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-89.br --context=89 --kb=$TESTPATH/tree-89.lp --manager=localhost:4999 --packsize=0 --port=5089 --queryplan=$TESTPATH/tree-89.qp --returnplan=$TESTPATH/tree-89.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-90.br --context=90 --kb=$TESTPATH/tree-90.lp --manager=localhost:4999 --packsize=0 --port=5090 --queryplan=$TESTPATH/tree-90.qp --returnplan=$TESTPATH/tree-90.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-91.br --context=91 --kb=$TESTPATH/tree-91.lp --manager=localhost:4999 --packsize=0 --port=5091 --queryplan=$TESTPATH/tree-91.qp --returnplan=$TESTPATH/tree-91.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-92.br --context=92 --kb=$TESTPATH/tree-92.lp --manager=localhost:4999 --packsize=0 --port=5092 --queryplan=$TESTPATH/tree-92.qp --returnplan=$TESTPATH/tree-92.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-93.br --context=93 --kb=$TESTPATH/tree-93.lp --manager=localhost:4999 --packsize=0 --port=5093 --queryplan=$TESTPATH/tree-93.qp --returnplan=$TESTPATH/tree-93.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-94.br --context=94 --kb=$TESTPATH/tree-94.lp --manager=localhost:4999 --packsize=0 --port=5094 --queryplan=$TESTPATH/tree-94.qp --returnplan=$TESTPATH/tree-94.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-95.br --context=95 --kb=$TESTPATH/tree-95.lp --manager=localhost:4999 --packsize=0 --port=5095 --queryplan=$TESTPATH/tree-95.qp --returnplan=$TESTPATH/tree-95.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-96.br --context=96 --kb=$TESTPATH/tree-96.lp --manager=localhost:4999 --packsize=0 --port=5096 --queryplan=$TESTPATH/tree-96.qp --returnplan=$TESTPATH/tree-96.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-97.br --context=97 --kb=$TESTPATH/tree-97.lp --manager=localhost:4999 --packsize=0 --port=5097 --queryplan=$TESTPATH/tree-97.qp --returnplan=$TESTPATH/tree-97.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-98.br --context=98 --kb=$TESTPATH/tree-98.lp --manager=localhost:4999 --packsize=0 --port=5098 --queryplan=$TESTPATH/tree-98.qp --returnplan=$TESTPATH/tree-98.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/tree-99.br --context=99 --kb=$TESTPATH/tree-99.lp --manager=localhost:4999 --packsize=0 --port=5099 --queryplan=$TESTPATH/tree-99.qp --returnplan=$TESTPATH/tree-99.rp --system-size=100  >/dev/null 2>&1 &
sleep 2
sleep 200
/usr/bin/time --verbose -o tree-time.log /usr/bin/timeout -k 20 $TIMEOUT $DMCSPATH/new_dmcsc --hostname=localhost --port=5000 --root=0 --signature=$TESTPATH/client.qp --belief-state-size=10 --k1=0 --k2=0 --loop=1 > tree.log 2> tree-err.log
