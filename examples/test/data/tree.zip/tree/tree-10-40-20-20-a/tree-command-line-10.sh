#!/bin/bash
export TIMEFORMAT=$'\nreal\t%3R\nuser\t%3U\nsys\t%3S'
export TIMEOUT=600
export TESTPATH='.'
export DMCSPATH='../../../../../build/src'
killall new_dmcsd
killall new_dmcsm
sleep 5
$DMCSPATH/new_dmcsm --port=4999 --system-size=10 &
sleep 5
$DMCSPATH/new_dmcsd --belief-state-size=40 --br=$TESTPATH/tree-0.br --context=0 --kb=$TESTPATH/tree-0.lp --manager=localhost:4999 --packsize=10 --port=5000 --queryplan=$TESTPATH/tree-0.qp --returnplan=$TESTPATH/tree-0.rp --system-size=10  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=40 --br=$TESTPATH/tree-1.br --context=1 --kb=$TESTPATH/tree-1.lp --manager=localhost:4999 --packsize=10 --port=5001 --queryplan=$TESTPATH/tree-1.qp --returnplan=$TESTPATH/tree-1.rp --system-size=10  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=40 --br=$TESTPATH/tree-2.br --context=2 --kb=$TESTPATH/tree-2.lp --manager=localhost:4999 --packsize=10 --port=5002 --queryplan=$TESTPATH/tree-2.qp --returnplan=$TESTPATH/tree-2.rp --system-size=10  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=40 --br=$TESTPATH/tree-3.br --context=3 --kb=$TESTPATH/tree-3.lp --manager=localhost:4999 --packsize=10 --port=5003 --queryplan=$TESTPATH/tree-3.qp --returnplan=$TESTPATH/tree-3.rp --system-size=10  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=40 --br=$TESTPATH/tree-4.br --context=4 --kb=$TESTPATH/tree-4.lp --manager=localhost:4999 --packsize=10 --port=5004 --queryplan=$TESTPATH/tree-4.qp --returnplan=$TESTPATH/tree-4.rp --system-size=10  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=40 --br=$TESTPATH/tree-5.br --context=5 --kb=$TESTPATH/tree-5.lp --manager=localhost:4999 --packsize=10 --port=5005 --queryplan=$TESTPATH/tree-5.qp --returnplan=$TESTPATH/tree-5.rp --system-size=10  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=40 --br=$TESTPATH/tree-6.br --context=6 --kb=$TESTPATH/tree-6.lp --manager=localhost:4999 --packsize=10 --port=5006 --queryplan=$TESTPATH/tree-6.qp --returnplan=$TESTPATH/tree-6.rp --system-size=10  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=40 --br=$TESTPATH/tree-7.br --context=7 --kb=$TESTPATH/tree-7.lp --manager=localhost:4999 --packsize=10 --port=5007 --queryplan=$TESTPATH/tree-7.qp --returnplan=$TESTPATH/tree-7.rp --system-size=10  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=40 --br=$TESTPATH/tree-8.br --context=8 --kb=$TESTPATH/tree-8.lp --manager=localhost:4999 --packsize=10 --port=5008 --queryplan=$TESTPATH/tree-8.qp --returnplan=$TESTPATH/tree-8.rp --system-size=10  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=40 --br=$TESTPATH/tree-9.br --context=9 --kb=$TESTPATH/tree-9.lp --manager=localhost:4999 --packsize=10 --port=5009 --queryplan=$TESTPATH/tree-9.qp --returnplan=$TESTPATH/tree-9.rp --system-size=10  >/dev/null 2>&1 &
sleep 2
sleep 20
/usr/bin/time --verbose -o tree-time.log /usr/bin/timeout -k 20 $TIMEOUT $DMCSPATH/new_dmcsc --hostname=localhost --port=5000 --root=0 --signature=$TESTPATH/client.qp --belief-state-size=40 --k1=1 --k2=10 --loop=1 > tree.log 2> tree-err.log
