#!/bin/bash
export TIMEFORMAT=$'\nreal\t%3R\nuser\t%3U\nsys\t%3S'
export TIMEOUT=600
export TESTPATH='.'
export DMCSPATH='../../../../../build/src'
killall new_dmcsd
killall new_dmcsm
sleep 5
$DMCSPATH/new_dmcsm --port=4999 --system-size=100 &
sleep 5
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-0.br --context=0 --kb=$TESTPATH/tree-0.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-0.oqp --packsize=100 --port=5000 --queryplan=$TESTPATH/tree-0.qp --returnplan=$TESTPATH/tree-0.orp --system-size=100  >tree-0.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-1.br --context=1 --kb=$TESTPATH/tree-1.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-1.oqp --packsize=100 --port=5001 --queryplan=$TESTPATH/tree-1.qp --returnplan=$TESTPATH/tree-1.orp --system-size=100  >tree-1.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-2.br --context=2 --kb=$TESTPATH/tree-2.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-2.oqp --packsize=100 --port=5002 --queryplan=$TESTPATH/tree-2.qp --returnplan=$TESTPATH/tree-2.orp --system-size=100  >tree-2.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-3.br --context=3 --kb=$TESTPATH/tree-3.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-3.oqp --packsize=100 --port=5003 --queryplan=$TESTPATH/tree-3.qp --returnplan=$TESTPATH/tree-3.orp --system-size=100  >tree-3.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-4.br --context=4 --kb=$TESTPATH/tree-4.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-4.oqp --packsize=100 --port=5004 --queryplan=$TESTPATH/tree-4.qp --returnplan=$TESTPATH/tree-4.orp --system-size=100  >tree-4.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-5.br --context=5 --kb=$TESTPATH/tree-5.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-5.oqp --packsize=100 --port=5005 --queryplan=$TESTPATH/tree-5.qp --returnplan=$TESTPATH/tree-5.orp --system-size=100  >tree-5.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-6.br --context=6 --kb=$TESTPATH/tree-6.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-6.oqp --packsize=100 --port=5006 --queryplan=$TESTPATH/tree-6.qp --returnplan=$TESTPATH/tree-6.orp --system-size=100  >tree-6.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-7.br --context=7 --kb=$TESTPATH/tree-7.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-7.oqp --packsize=100 --port=5007 --queryplan=$TESTPATH/tree-7.qp --returnplan=$TESTPATH/tree-7.orp --system-size=100  >tree-7.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-8.br --context=8 --kb=$TESTPATH/tree-8.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-8.oqp --packsize=100 --port=5008 --queryplan=$TESTPATH/tree-8.qp --returnplan=$TESTPATH/tree-8.orp --system-size=100  >tree-8.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-9.br --context=9 --kb=$TESTPATH/tree-9.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-9.oqp --packsize=100 --port=5009 --queryplan=$TESTPATH/tree-9.qp --returnplan=$TESTPATH/tree-9.orp --system-size=100  >tree-9.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-10.br --context=10 --kb=$TESTPATH/tree-10.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-10.oqp --packsize=100 --port=5010 --queryplan=$TESTPATH/tree-10.qp --returnplan=$TESTPATH/tree-10.orp --system-size=100  >tree-10.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-11.br --context=11 --kb=$TESTPATH/tree-11.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-11.oqp --packsize=100 --port=5011 --queryplan=$TESTPATH/tree-11.qp --returnplan=$TESTPATH/tree-11.orp --system-size=100  >tree-11.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-12.br --context=12 --kb=$TESTPATH/tree-12.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-12.oqp --packsize=100 --port=5012 --queryplan=$TESTPATH/tree-12.qp --returnplan=$TESTPATH/tree-12.orp --system-size=100  >tree-12.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-13.br --context=13 --kb=$TESTPATH/tree-13.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-13.oqp --packsize=100 --port=5013 --queryplan=$TESTPATH/tree-13.qp --returnplan=$TESTPATH/tree-13.orp --system-size=100  >tree-13.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-14.br --context=14 --kb=$TESTPATH/tree-14.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-14.oqp --packsize=100 --port=5014 --queryplan=$TESTPATH/tree-14.qp --returnplan=$TESTPATH/tree-14.orp --system-size=100  >tree-14.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-15.br --context=15 --kb=$TESTPATH/tree-15.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-15.oqp --packsize=100 --port=5015 --queryplan=$TESTPATH/tree-15.qp --returnplan=$TESTPATH/tree-15.orp --system-size=100  >tree-15.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-16.br --context=16 --kb=$TESTPATH/tree-16.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-16.oqp --packsize=100 --port=5016 --queryplan=$TESTPATH/tree-16.qp --returnplan=$TESTPATH/tree-16.orp --system-size=100  >tree-16.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-17.br --context=17 --kb=$TESTPATH/tree-17.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-17.oqp --packsize=100 --port=5017 --queryplan=$TESTPATH/tree-17.qp --returnplan=$TESTPATH/tree-17.orp --system-size=100  >tree-17.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-18.br --context=18 --kb=$TESTPATH/tree-18.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-18.oqp --packsize=100 --port=5018 --queryplan=$TESTPATH/tree-18.qp --returnplan=$TESTPATH/tree-18.orp --system-size=100  >tree-18.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-19.br --context=19 --kb=$TESTPATH/tree-19.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-19.oqp --packsize=100 --port=5019 --queryplan=$TESTPATH/tree-19.qp --returnplan=$TESTPATH/tree-19.orp --system-size=100  >tree-19.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-20.br --context=20 --kb=$TESTPATH/tree-20.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-20.oqp --packsize=100 --port=5020 --queryplan=$TESTPATH/tree-20.qp --returnplan=$TESTPATH/tree-20.orp --system-size=100  >tree-20.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-21.br --context=21 --kb=$TESTPATH/tree-21.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-21.oqp --packsize=100 --port=5021 --queryplan=$TESTPATH/tree-21.qp --returnplan=$TESTPATH/tree-21.orp --system-size=100  >tree-21.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-22.br --context=22 --kb=$TESTPATH/tree-22.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-22.oqp --packsize=100 --port=5022 --queryplan=$TESTPATH/tree-22.qp --returnplan=$TESTPATH/tree-22.orp --system-size=100  >tree-22.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-23.br --context=23 --kb=$TESTPATH/tree-23.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-23.oqp --packsize=100 --port=5023 --queryplan=$TESTPATH/tree-23.qp --returnplan=$TESTPATH/tree-23.orp --system-size=100  >tree-23.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-24.br --context=24 --kb=$TESTPATH/tree-24.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-24.oqp --packsize=100 --port=5024 --queryplan=$TESTPATH/tree-24.qp --returnplan=$TESTPATH/tree-24.orp --system-size=100  >tree-24.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-25.br --context=25 --kb=$TESTPATH/tree-25.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-25.oqp --packsize=100 --port=5025 --queryplan=$TESTPATH/tree-25.qp --returnplan=$TESTPATH/tree-25.orp --system-size=100  >tree-25.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-26.br --context=26 --kb=$TESTPATH/tree-26.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-26.oqp --packsize=100 --port=5026 --queryplan=$TESTPATH/tree-26.qp --returnplan=$TESTPATH/tree-26.orp --system-size=100  >tree-26.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-27.br --context=27 --kb=$TESTPATH/tree-27.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-27.oqp --packsize=100 --port=5027 --queryplan=$TESTPATH/tree-27.qp --returnplan=$TESTPATH/tree-27.orp --system-size=100  >tree-27.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-28.br --context=28 --kb=$TESTPATH/tree-28.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-28.oqp --packsize=100 --port=5028 --queryplan=$TESTPATH/tree-28.qp --returnplan=$TESTPATH/tree-28.orp --system-size=100  >tree-28.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-29.br --context=29 --kb=$TESTPATH/tree-29.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-29.oqp --packsize=100 --port=5029 --queryplan=$TESTPATH/tree-29.qp --returnplan=$TESTPATH/tree-29.orp --system-size=100  >tree-29.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-30.br --context=30 --kb=$TESTPATH/tree-30.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-30.oqp --packsize=100 --port=5030 --queryplan=$TESTPATH/tree-30.qp --returnplan=$TESTPATH/tree-30.orp --system-size=100  >tree-30.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-31.br --context=31 --kb=$TESTPATH/tree-31.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-31.oqp --packsize=100 --port=5031 --queryplan=$TESTPATH/tree-31.qp --returnplan=$TESTPATH/tree-31.orp --system-size=100  >tree-31.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-32.br --context=32 --kb=$TESTPATH/tree-32.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-32.oqp --packsize=100 --port=5032 --queryplan=$TESTPATH/tree-32.qp --returnplan=$TESTPATH/tree-32.orp --system-size=100  >tree-32.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-33.br --context=33 --kb=$TESTPATH/tree-33.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-33.oqp --packsize=100 --port=5033 --queryplan=$TESTPATH/tree-33.qp --returnplan=$TESTPATH/tree-33.orp --system-size=100  >tree-33.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-34.br --context=34 --kb=$TESTPATH/tree-34.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-34.oqp --packsize=100 --port=5034 --queryplan=$TESTPATH/tree-34.qp --returnplan=$TESTPATH/tree-34.orp --system-size=100  >tree-34.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-35.br --context=35 --kb=$TESTPATH/tree-35.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-35.oqp --packsize=100 --port=5035 --queryplan=$TESTPATH/tree-35.qp --returnplan=$TESTPATH/tree-35.orp --system-size=100  >tree-35.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-36.br --context=36 --kb=$TESTPATH/tree-36.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-36.oqp --packsize=100 --port=5036 --queryplan=$TESTPATH/tree-36.qp --returnplan=$TESTPATH/tree-36.orp --system-size=100  >tree-36.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-37.br --context=37 --kb=$TESTPATH/tree-37.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-37.oqp --packsize=100 --port=5037 --queryplan=$TESTPATH/tree-37.qp --returnplan=$TESTPATH/tree-37.orp --system-size=100  >tree-37.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-38.br --context=38 --kb=$TESTPATH/tree-38.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-38.oqp --packsize=100 --port=5038 --queryplan=$TESTPATH/tree-38.qp --returnplan=$TESTPATH/tree-38.orp --system-size=100  >tree-38.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-39.br --context=39 --kb=$TESTPATH/tree-39.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-39.oqp --packsize=100 --port=5039 --queryplan=$TESTPATH/tree-39.qp --returnplan=$TESTPATH/tree-39.orp --system-size=100  >tree-39.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-40.br --context=40 --kb=$TESTPATH/tree-40.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-40.oqp --packsize=100 --port=5040 --queryplan=$TESTPATH/tree-40.qp --returnplan=$TESTPATH/tree-40.orp --system-size=100  >tree-40.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-41.br --context=41 --kb=$TESTPATH/tree-41.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-41.oqp --packsize=100 --port=5041 --queryplan=$TESTPATH/tree-41.qp --returnplan=$TESTPATH/tree-41.orp --system-size=100  >tree-41.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-42.br --context=42 --kb=$TESTPATH/tree-42.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-42.oqp --packsize=100 --port=5042 --queryplan=$TESTPATH/tree-42.qp --returnplan=$TESTPATH/tree-42.orp --system-size=100  >tree-42.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-43.br --context=43 --kb=$TESTPATH/tree-43.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-43.oqp --packsize=100 --port=5043 --queryplan=$TESTPATH/tree-43.qp --returnplan=$TESTPATH/tree-43.orp --system-size=100  >tree-43.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-44.br --context=44 --kb=$TESTPATH/tree-44.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-44.oqp --packsize=100 --port=5044 --queryplan=$TESTPATH/tree-44.qp --returnplan=$TESTPATH/tree-44.orp --system-size=100  >tree-44.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-45.br --context=45 --kb=$TESTPATH/tree-45.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-45.oqp --packsize=100 --port=5045 --queryplan=$TESTPATH/tree-45.qp --returnplan=$TESTPATH/tree-45.orp --system-size=100  >tree-45.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-46.br --context=46 --kb=$TESTPATH/tree-46.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-46.oqp --packsize=100 --port=5046 --queryplan=$TESTPATH/tree-46.qp --returnplan=$TESTPATH/tree-46.orp --system-size=100  >tree-46.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-47.br --context=47 --kb=$TESTPATH/tree-47.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-47.oqp --packsize=100 --port=5047 --queryplan=$TESTPATH/tree-47.qp --returnplan=$TESTPATH/tree-47.orp --system-size=100  >tree-47.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-48.br --context=48 --kb=$TESTPATH/tree-48.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-48.oqp --packsize=100 --port=5048 --queryplan=$TESTPATH/tree-48.qp --returnplan=$TESTPATH/tree-48.orp --system-size=100  >tree-48.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-49.br --context=49 --kb=$TESTPATH/tree-49.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-49.oqp --packsize=100 --port=5049 --queryplan=$TESTPATH/tree-49.qp --returnplan=$TESTPATH/tree-49.orp --system-size=100  >tree-49.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-50.br --context=50 --kb=$TESTPATH/tree-50.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-50.oqp --packsize=100 --port=5050 --queryplan=$TESTPATH/tree-50.qp --returnplan=$TESTPATH/tree-50.orp --system-size=100  >tree-50.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-51.br --context=51 --kb=$TESTPATH/tree-51.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-51.oqp --packsize=100 --port=5051 --queryplan=$TESTPATH/tree-51.qp --returnplan=$TESTPATH/tree-51.orp --system-size=100  >tree-51.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-52.br --context=52 --kb=$TESTPATH/tree-52.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-52.oqp --packsize=100 --port=5052 --queryplan=$TESTPATH/tree-52.qp --returnplan=$TESTPATH/tree-52.orp --system-size=100  >tree-52.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-53.br --context=53 --kb=$TESTPATH/tree-53.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-53.oqp --packsize=100 --port=5053 --queryplan=$TESTPATH/tree-53.qp --returnplan=$TESTPATH/tree-53.orp --system-size=100  >tree-53.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-54.br --context=54 --kb=$TESTPATH/tree-54.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-54.oqp --packsize=100 --port=5054 --queryplan=$TESTPATH/tree-54.qp --returnplan=$TESTPATH/tree-54.orp --system-size=100  >tree-54.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-55.br --context=55 --kb=$TESTPATH/tree-55.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-55.oqp --packsize=100 --port=5055 --queryplan=$TESTPATH/tree-55.qp --returnplan=$TESTPATH/tree-55.orp --system-size=100  >tree-55.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-56.br --context=56 --kb=$TESTPATH/tree-56.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-56.oqp --packsize=100 --port=5056 --queryplan=$TESTPATH/tree-56.qp --returnplan=$TESTPATH/tree-56.orp --system-size=100  >tree-56.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-57.br --context=57 --kb=$TESTPATH/tree-57.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-57.oqp --packsize=100 --port=5057 --queryplan=$TESTPATH/tree-57.qp --returnplan=$TESTPATH/tree-57.orp --system-size=100  >tree-57.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-58.br --context=58 --kb=$TESTPATH/tree-58.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-58.oqp --packsize=100 --port=5058 --queryplan=$TESTPATH/tree-58.qp --returnplan=$TESTPATH/tree-58.orp --system-size=100  >tree-58.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-59.br --context=59 --kb=$TESTPATH/tree-59.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-59.oqp --packsize=100 --port=5059 --queryplan=$TESTPATH/tree-59.qp --returnplan=$TESTPATH/tree-59.orp --system-size=100  >tree-59.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-60.br --context=60 --kb=$TESTPATH/tree-60.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-60.oqp --packsize=100 --port=5060 --queryplan=$TESTPATH/tree-60.qp --returnplan=$TESTPATH/tree-60.orp --system-size=100  >tree-60.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-61.br --context=61 --kb=$TESTPATH/tree-61.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-61.oqp --packsize=100 --port=5061 --queryplan=$TESTPATH/tree-61.qp --returnplan=$TESTPATH/tree-61.orp --system-size=100  >tree-61.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-62.br --context=62 --kb=$TESTPATH/tree-62.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-62.oqp --packsize=100 --port=5062 --queryplan=$TESTPATH/tree-62.qp --returnplan=$TESTPATH/tree-62.orp --system-size=100  >tree-62.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-63.br --context=63 --kb=$TESTPATH/tree-63.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-63.oqp --packsize=100 --port=5063 --queryplan=$TESTPATH/tree-63.qp --returnplan=$TESTPATH/tree-63.orp --system-size=100  >tree-63.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-64.br --context=64 --kb=$TESTPATH/tree-64.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-64.oqp --packsize=100 --port=5064 --queryplan=$TESTPATH/tree-64.qp --returnplan=$TESTPATH/tree-64.orp --system-size=100  >tree-64.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-65.br --context=65 --kb=$TESTPATH/tree-65.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-65.oqp --packsize=100 --port=5065 --queryplan=$TESTPATH/tree-65.qp --returnplan=$TESTPATH/tree-65.orp --system-size=100  >tree-65.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-66.br --context=66 --kb=$TESTPATH/tree-66.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-66.oqp --packsize=100 --port=5066 --queryplan=$TESTPATH/tree-66.qp --returnplan=$TESTPATH/tree-66.orp --system-size=100  >tree-66.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-67.br --context=67 --kb=$TESTPATH/tree-67.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-67.oqp --packsize=100 --port=5067 --queryplan=$TESTPATH/tree-67.qp --returnplan=$TESTPATH/tree-67.orp --system-size=100  >tree-67.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-68.br --context=68 --kb=$TESTPATH/tree-68.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-68.oqp --packsize=100 --port=5068 --queryplan=$TESTPATH/tree-68.qp --returnplan=$TESTPATH/tree-68.orp --system-size=100  >tree-68.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-69.br --context=69 --kb=$TESTPATH/tree-69.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-69.oqp --packsize=100 --port=5069 --queryplan=$TESTPATH/tree-69.qp --returnplan=$TESTPATH/tree-69.orp --system-size=100  >tree-69.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-70.br --context=70 --kb=$TESTPATH/tree-70.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-70.oqp --packsize=100 --port=5070 --queryplan=$TESTPATH/tree-70.qp --returnplan=$TESTPATH/tree-70.orp --system-size=100  >tree-70.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-71.br --context=71 --kb=$TESTPATH/tree-71.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-71.oqp --packsize=100 --port=5071 --queryplan=$TESTPATH/tree-71.qp --returnplan=$TESTPATH/tree-71.orp --system-size=100  >tree-71.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-72.br --context=72 --kb=$TESTPATH/tree-72.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-72.oqp --packsize=100 --port=5072 --queryplan=$TESTPATH/tree-72.qp --returnplan=$TESTPATH/tree-72.orp --system-size=100  >tree-72.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-73.br --context=73 --kb=$TESTPATH/tree-73.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-73.oqp --packsize=100 --port=5073 --queryplan=$TESTPATH/tree-73.qp --returnplan=$TESTPATH/tree-73.orp --system-size=100  >tree-73.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-74.br --context=74 --kb=$TESTPATH/tree-74.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-74.oqp --packsize=100 --port=5074 --queryplan=$TESTPATH/tree-74.qp --returnplan=$TESTPATH/tree-74.orp --system-size=100  >tree-74.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-75.br --context=75 --kb=$TESTPATH/tree-75.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-75.oqp --packsize=100 --port=5075 --queryplan=$TESTPATH/tree-75.qp --returnplan=$TESTPATH/tree-75.orp --system-size=100  >tree-75.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-76.br --context=76 --kb=$TESTPATH/tree-76.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-76.oqp --packsize=100 --port=5076 --queryplan=$TESTPATH/tree-76.qp --returnplan=$TESTPATH/tree-76.orp --system-size=100  >tree-76.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-77.br --context=77 --kb=$TESTPATH/tree-77.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-77.oqp --packsize=100 --port=5077 --queryplan=$TESTPATH/tree-77.qp --returnplan=$TESTPATH/tree-77.orp --system-size=100  >tree-77.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-78.br --context=78 --kb=$TESTPATH/tree-78.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-78.oqp --packsize=100 --port=5078 --queryplan=$TESTPATH/tree-78.qp --returnplan=$TESTPATH/tree-78.orp --system-size=100  >tree-78.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-79.br --context=79 --kb=$TESTPATH/tree-79.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-79.oqp --packsize=100 --port=5079 --queryplan=$TESTPATH/tree-79.qp --returnplan=$TESTPATH/tree-79.orp --system-size=100  >tree-79.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-80.br --context=80 --kb=$TESTPATH/tree-80.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-80.oqp --packsize=100 --port=5080 --queryplan=$TESTPATH/tree-80.qp --returnplan=$TESTPATH/tree-80.orp --system-size=100  >tree-80.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-81.br --context=81 --kb=$TESTPATH/tree-81.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-81.oqp --packsize=100 --port=5081 --queryplan=$TESTPATH/tree-81.qp --returnplan=$TESTPATH/tree-81.orp --system-size=100  >tree-81.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-82.br --context=82 --kb=$TESTPATH/tree-82.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-82.oqp --packsize=100 --port=5082 --queryplan=$TESTPATH/tree-82.qp --returnplan=$TESTPATH/tree-82.orp --system-size=100  >tree-82.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-83.br --context=83 --kb=$TESTPATH/tree-83.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-83.oqp --packsize=100 --port=5083 --queryplan=$TESTPATH/tree-83.qp --returnplan=$TESTPATH/tree-83.orp --system-size=100  >tree-83.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-84.br --context=84 --kb=$TESTPATH/tree-84.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-84.oqp --packsize=100 --port=5084 --queryplan=$TESTPATH/tree-84.qp --returnplan=$TESTPATH/tree-84.orp --system-size=100  >tree-84.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-85.br --context=85 --kb=$TESTPATH/tree-85.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-85.oqp --packsize=100 --port=5085 --queryplan=$TESTPATH/tree-85.qp --returnplan=$TESTPATH/tree-85.orp --system-size=100  >tree-85.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-86.br --context=86 --kb=$TESTPATH/tree-86.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-86.oqp --packsize=100 --port=5086 --queryplan=$TESTPATH/tree-86.qp --returnplan=$TESTPATH/tree-86.orp --system-size=100  >tree-86.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-87.br --context=87 --kb=$TESTPATH/tree-87.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-87.oqp --packsize=100 --port=5087 --queryplan=$TESTPATH/tree-87.qp --returnplan=$TESTPATH/tree-87.orp --system-size=100  >tree-87.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-88.br --context=88 --kb=$TESTPATH/tree-88.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-88.oqp --packsize=100 --port=5088 --queryplan=$TESTPATH/tree-88.qp --returnplan=$TESTPATH/tree-88.orp --system-size=100  >tree-88.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-89.br --context=89 --kb=$TESTPATH/tree-89.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-89.oqp --packsize=100 --port=5089 --queryplan=$TESTPATH/tree-89.qp --returnplan=$TESTPATH/tree-89.orp --system-size=100  >tree-89.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-90.br --context=90 --kb=$TESTPATH/tree-90.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-90.oqp --packsize=100 --port=5090 --queryplan=$TESTPATH/tree-90.qp --returnplan=$TESTPATH/tree-90.orp --system-size=100  >tree-90.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-91.br --context=91 --kb=$TESTPATH/tree-91.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-91.oqp --packsize=100 --port=5091 --queryplan=$TESTPATH/tree-91.qp --returnplan=$TESTPATH/tree-91.orp --system-size=100  >tree-91.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-92.br --context=92 --kb=$TESTPATH/tree-92.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-92.oqp --packsize=100 --port=5092 --queryplan=$TESTPATH/tree-92.qp --returnplan=$TESTPATH/tree-92.orp --system-size=100  >tree-92.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-93.br --context=93 --kb=$TESTPATH/tree-93.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-93.oqp --packsize=100 --port=5093 --queryplan=$TESTPATH/tree-93.qp --returnplan=$TESTPATH/tree-93.orp --system-size=100  >tree-93.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-94.br --context=94 --kb=$TESTPATH/tree-94.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-94.oqp --packsize=100 --port=5094 --queryplan=$TESTPATH/tree-94.qp --returnplan=$TESTPATH/tree-94.orp --system-size=100  >tree-94.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-95.br --context=95 --kb=$TESTPATH/tree-95.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-95.oqp --packsize=100 --port=5095 --queryplan=$TESTPATH/tree-95.qp --returnplan=$TESTPATH/tree-95.orp --system-size=100  >tree-95.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-96.br --context=96 --kb=$TESTPATH/tree-96.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-96.oqp --packsize=100 --port=5096 --queryplan=$TESTPATH/tree-96.qp --returnplan=$TESTPATH/tree-96.orp --system-size=100  >tree-96.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-97.br --context=97 --kb=$TESTPATH/tree-97.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-97.oqp --packsize=100 --port=5097 --queryplan=$TESTPATH/tree-97.qp --returnplan=$TESTPATH/tree-97.orp --system-size=100  >tree-97.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-98.br --context=98 --kb=$TESTPATH/tree-98.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-98.oqp --packsize=100 --port=5098 --queryplan=$TESTPATH/tree-98.qp --returnplan=$TESTPATH/tree-98.orp --system-size=100  >tree-98.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/tree-99.br --context=99 --kb=$TESTPATH/tree-99.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/tree-99.oqp --packsize=100 --port=5099 --queryplan=$TESTPATH/tree-99.qp --returnplan=$TESTPATH/tree-99.orp --system-size=100  >tree-99.log 2>&1 &
sleep 2
sleep 200
/usr/bin/time --verbose -o tree-time.log /usr/bin/timeout -k 20 $TIMEOUT $DMCSPATH/new_dmcsc --hostname=localhost --port=5000 --root=0 --signature=$TESTPATH/client.qp --belief-state-size=20 --k1=1 --k2=100 --loop=1 > tree.log 2> tree-err.log
