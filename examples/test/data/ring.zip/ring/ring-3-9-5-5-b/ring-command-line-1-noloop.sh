#!/bin/bash
export TIMEFORMAT=$'\nreal\t%3R\nuser\t%3U\nsys\t%3S'
export TIMEOUT=600
export TESTPATH='.'
export DMCSPATH='../../../../../build/src'
killall new_dmcsd
killall new_dmcsm
sleep 5
$DMCSPATH/new_dmcsm --port=4999 --system-size=3 &
sleep 5
$DMCSPATH/new_dmcsd --belief-state-size=9 --br=$TESTPATH/ring-0.br --context=0 --kb=$TESTPATH/ring-0.lp --manager=localhost:4999 --packsize=1 --port=5000 --queryplan=$TESTPATH/ring-0.qp --returnplan=$TESTPATH/ring-0.rp --system-size=3  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=9 --br=$TESTPATH/ring-1.br --context=1 --kb=$TESTPATH/ring-1.lp --manager=localhost:4999 --packsize=1 --port=5001 --queryplan=$TESTPATH/ring-1.qp --returnplan=$TESTPATH/ring-1.rp --system-size=3  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=9 --br=$TESTPATH/ring-2.br --context=2 --kb=$TESTPATH/ring-2.lp --manager=localhost:4999 --packsize=1 --port=5002 --queryplan=$TESTPATH/ring-2.qp --returnplan=$TESTPATH/ring-2.rp --system-size=3  >/dev/null 2>&1 &
sleep 2
sleep 6
/usr/bin/time --verbose -o ring-time.log /usr/bin/timeout -k 20 $TIMEOUT $DMCSPATH/new_dmcsc --hostname=localhost --port=5000 --root=0 --signature=$TESTPATH/client.qp --belief-state-size=9 --k1=1 --k2=1 --loop=0 > ring.log 2> ring-err.log
