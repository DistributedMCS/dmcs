#!/bin/bash
export TIMEFORMAT=$'\nreal\t%3R\nuser\t%3U\nsys\t%3S'
export TIMEOUT=600
export TESTPATH='.'
export DMCSPATH='../../../../../build/src'
killall new_dmcsd
killall new_dmcsm
sleep 5
$DMCSPATH/new_dmcsm --port=4999 --system-size=70 &
sleep 5
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-0.br --context=0 --kb=$TESTPATH/ring-0.lp --manager=localhost:4999 --packsize=1 --port=5000 --queryplan=$TESTPATH/ring-0.qp --returnplan=$TESTPATH/ring-0.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-1.br --context=1 --kb=$TESTPATH/ring-1.lp --manager=localhost:4999 --packsize=1 --port=5001 --queryplan=$TESTPATH/ring-1.qp --returnplan=$TESTPATH/ring-1.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-2.br --context=2 --kb=$TESTPATH/ring-2.lp --manager=localhost:4999 --packsize=1 --port=5002 --queryplan=$TESTPATH/ring-2.qp --returnplan=$TESTPATH/ring-2.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-3.br --context=3 --kb=$TESTPATH/ring-3.lp --manager=localhost:4999 --packsize=1 --port=5003 --queryplan=$TESTPATH/ring-3.qp --returnplan=$TESTPATH/ring-3.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-4.br --context=4 --kb=$TESTPATH/ring-4.lp --manager=localhost:4999 --packsize=1 --port=5004 --queryplan=$TESTPATH/ring-4.qp --returnplan=$TESTPATH/ring-4.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-5.br --context=5 --kb=$TESTPATH/ring-5.lp --manager=localhost:4999 --packsize=1 --port=5005 --queryplan=$TESTPATH/ring-5.qp --returnplan=$TESTPATH/ring-5.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-6.br --context=6 --kb=$TESTPATH/ring-6.lp --manager=localhost:4999 --packsize=1 --port=5006 --queryplan=$TESTPATH/ring-6.qp --returnplan=$TESTPATH/ring-6.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-7.br --context=7 --kb=$TESTPATH/ring-7.lp --manager=localhost:4999 --packsize=1 --port=5007 --queryplan=$TESTPATH/ring-7.qp --returnplan=$TESTPATH/ring-7.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-8.br --context=8 --kb=$TESTPATH/ring-8.lp --manager=localhost:4999 --packsize=1 --port=5008 --queryplan=$TESTPATH/ring-8.qp --returnplan=$TESTPATH/ring-8.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-9.br --context=9 --kb=$TESTPATH/ring-9.lp --manager=localhost:4999 --packsize=1 --port=5009 --queryplan=$TESTPATH/ring-9.qp --returnplan=$TESTPATH/ring-9.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-10.br --context=10 --kb=$TESTPATH/ring-10.lp --manager=localhost:4999 --packsize=1 --port=5010 --queryplan=$TESTPATH/ring-10.qp --returnplan=$TESTPATH/ring-10.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-11.br --context=11 --kb=$TESTPATH/ring-11.lp --manager=localhost:4999 --packsize=1 --port=5011 --queryplan=$TESTPATH/ring-11.qp --returnplan=$TESTPATH/ring-11.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-12.br --context=12 --kb=$TESTPATH/ring-12.lp --manager=localhost:4999 --packsize=1 --port=5012 --queryplan=$TESTPATH/ring-12.qp --returnplan=$TESTPATH/ring-12.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-13.br --context=13 --kb=$TESTPATH/ring-13.lp --manager=localhost:4999 --packsize=1 --port=5013 --queryplan=$TESTPATH/ring-13.qp --returnplan=$TESTPATH/ring-13.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-14.br --context=14 --kb=$TESTPATH/ring-14.lp --manager=localhost:4999 --packsize=1 --port=5014 --queryplan=$TESTPATH/ring-14.qp --returnplan=$TESTPATH/ring-14.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-15.br --context=15 --kb=$TESTPATH/ring-15.lp --manager=localhost:4999 --packsize=1 --port=5015 --queryplan=$TESTPATH/ring-15.qp --returnplan=$TESTPATH/ring-15.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-16.br --context=16 --kb=$TESTPATH/ring-16.lp --manager=localhost:4999 --packsize=1 --port=5016 --queryplan=$TESTPATH/ring-16.qp --returnplan=$TESTPATH/ring-16.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-17.br --context=17 --kb=$TESTPATH/ring-17.lp --manager=localhost:4999 --packsize=1 --port=5017 --queryplan=$TESTPATH/ring-17.qp --returnplan=$TESTPATH/ring-17.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-18.br --context=18 --kb=$TESTPATH/ring-18.lp --manager=localhost:4999 --packsize=1 --port=5018 --queryplan=$TESTPATH/ring-18.qp --returnplan=$TESTPATH/ring-18.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-19.br --context=19 --kb=$TESTPATH/ring-19.lp --manager=localhost:4999 --packsize=1 --port=5019 --queryplan=$TESTPATH/ring-19.qp --returnplan=$TESTPATH/ring-19.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-20.br --context=20 --kb=$TESTPATH/ring-20.lp --manager=localhost:4999 --packsize=1 --port=5020 --queryplan=$TESTPATH/ring-20.qp --returnplan=$TESTPATH/ring-20.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-21.br --context=21 --kb=$TESTPATH/ring-21.lp --manager=localhost:4999 --packsize=1 --port=5021 --queryplan=$TESTPATH/ring-21.qp --returnplan=$TESTPATH/ring-21.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-22.br --context=22 --kb=$TESTPATH/ring-22.lp --manager=localhost:4999 --packsize=1 --port=5022 --queryplan=$TESTPATH/ring-22.qp --returnplan=$TESTPATH/ring-22.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-23.br --context=23 --kb=$TESTPATH/ring-23.lp --manager=localhost:4999 --packsize=1 --port=5023 --queryplan=$TESTPATH/ring-23.qp --returnplan=$TESTPATH/ring-23.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-24.br --context=24 --kb=$TESTPATH/ring-24.lp --manager=localhost:4999 --packsize=1 --port=5024 --queryplan=$TESTPATH/ring-24.qp --returnplan=$TESTPATH/ring-24.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-25.br --context=25 --kb=$TESTPATH/ring-25.lp --manager=localhost:4999 --packsize=1 --port=5025 --queryplan=$TESTPATH/ring-25.qp --returnplan=$TESTPATH/ring-25.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-26.br --context=26 --kb=$TESTPATH/ring-26.lp --manager=localhost:4999 --packsize=1 --port=5026 --queryplan=$TESTPATH/ring-26.qp --returnplan=$TESTPATH/ring-26.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-27.br --context=27 --kb=$TESTPATH/ring-27.lp --manager=localhost:4999 --packsize=1 --port=5027 --queryplan=$TESTPATH/ring-27.qp --returnplan=$TESTPATH/ring-27.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-28.br --context=28 --kb=$TESTPATH/ring-28.lp --manager=localhost:4999 --packsize=1 --port=5028 --queryplan=$TESTPATH/ring-28.qp --returnplan=$TESTPATH/ring-28.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-29.br --context=29 --kb=$TESTPATH/ring-29.lp --manager=localhost:4999 --packsize=1 --port=5029 --queryplan=$TESTPATH/ring-29.qp --returnplan=$TESTPATH/ring-29.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-30.br --context=30 --kb=$TESTPATH/ring-30.lp --manager=localhost:4999 --packsize=1 --port=5030 --queryplan=$TESTPATH/ring-30.qp --returnplan=$TESTPATH/ring-30.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-31.br --context=31 --kb=$TESTPATH/ring-31.lp --manager=localhost:4999 --packsize=1 --port=5031 --queryplan=$TESTPATH/ring-31.qp --returnplan=$TESTPATH/ring-31.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-32.br --context=32 --kb=$TESTPATH/ring-32.lp --manager=localhost:4999 --packsize=1 --port=5032 --queryplan=$TESTPATH/ring-32.qp --returnplan=$TESTPATH/ring-32.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-33.br --context=33 --kb=$TESTPATH/ring-33.lp --manager=localhost:4999 --packsize=1 --port=5033 --queryplan=$TESTPATH/ring-33.qp --returnplan=$TESTPATH/ring-33.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-34.br --context=34 --kb=$TESTPATH/ring-34.lp --manager=localhost:4999 --packsize=1 --port=5034 --queryplan=$TESTPATH/ring-34.qp --returnplan=$TESTPATH/ring-34.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-35.br --context=35 --kb=$TESTPATH/ring-35.lp --manager=localhost:4999 --packsize=1 --port=5035 --queryplan=$TESTPATH/ring-35.qp --returnplan=$TESTPATH/ring-35.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-36.br --context=36 --kb=$TESTPATH/ring-36.lp --manager=localhost:4999 --packsize=1 --port=5036 --queryplan=$TESTPATH/ring-36.qp --returnplan=$TESTPATH/ring-36.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-37.br --context=37 --kb=$TESTPATH/ring-37.lp --manager=localhost:4999 --packsize=1 --port=5037 --queryplan=$TESTPATH/ring-37.qp --returnplan=$TESTPATH/ring-37.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-38.br --context=38 --kb=$TESTPATH/ring-38.lp --manager=localhost:4999 --packsize=1 --port=5038 --queryplan=$TESTPATH/ring-38.qp --returnplan=$TESTPATH/ring-38.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-39.br --context=39 --kb=$TESTPATH/ring-39.lp --manager=localhost:4999 --packsize=1 --port=5039 --queryplan=$TESTPATH/ring-39.qp --returnplan=$TESTPATH/ring-39.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-40.br --context=40 --kb=$TESTPATH/ring-40.lp --manager=localhost:4999 --packsize=1 --port=5040 --queryplan=$TESTPATH/ring-40.qp --returnplan=$TESTPATH/ring-40.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-41.br --context=41 --kb=$TESTPATH/ring-41.lp --manager=localhost:4999 --packsize=1 --port=5041 --queryplan=$TESTPATH/ring-41.qp --returnplan=$TESTPATH/ring-41.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-42.br --context=42 --kb=$TESTPATH/ring-42.lp --manager=localhost:4999 --packsize=1 --port=5042 --queryplan=$TESTPATH/ring-42.qp --returnplan=$TESTPATH/ring-42.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-43.br --context=43 --kb=$TESTPATH/ring-43.lp --manager=localhost:4999 --packsize=1 --port=5043 --queryplan=$TESTPATH/ring-43.qp --returnplan=$TESTPATH/ring-43.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-44.br --context=44 --kb=$TESTPATH/ring-44.lp --manager=localhost:4999 --packsize=1 --port=5044 --queryplan=$TESTPATH/ring-44.qp --returnplan=$TESTPATH/ring-44.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-45.br --context=45 --kb=$TESTPATH/ring-45.lp --manager=localhost:4999 --packsize=1 --port=5045 --queryplan=$TESTPATH/ring-45.qp --returnplan=$TESTPATH/ring-45.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-46.br --context=46 --kb=$TESTPATH/ring-46.lp --manager=localhost:4999 --packsize=1 --port=5046 --queryplan=$TESTPATH/ring-46.qp --returnplan=$TESTPATH/ring-46.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-47.br --context=47 --kb=$TESTPATH/ring-47.lp --manager=localhost:4999 --packsize=1 --port=5047 --queryplan=$TESTPATH/ring-47.qp --returnplan=$TESTPATH/ring-47.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-48.br --context=48 --kb=$TESTPATH/ring-48.lp --manager=localhost:4999 --packsize=1 --port=5048 --queryplan=$TESTPATH/ring-48.qp --returnplan=$TESTPATH/ring-48.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-49.br --context=49 --kb=$TESTPATH/ring-49.lp --manager=localhost:4999 --packsize=1 --port=5049 --queryplan=$TESTPATH/ring-49.qp --returnplan=$TESTPATH/ring-49.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-50.br --context=50 --kb=$TESTPATH/ring-50.lp --manager=localhost:4999 --packsize=1 --port=5050 --queryplan=$TESTPATH/ring-50.qp --returnplan=$TESTPATH/ring-50.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-51.br --context=51 --kb=$TESTPATH/ring-51.lp --manager=localhost:4999 --packsize=1 --port=5051 --queryplan=$TESTPATH/ring-51.qp --returnplan=$TESTPATH/ring-51.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-52.br --context=52 --kb=$TESTPATH/ring-52.lp --manager=localhost:4999 --packsize=1 --port=5052 --queryplan=$TESTPATH/ring-52.qp --returnplan=$TESTPATH/ring-52.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-53.br --context=53 --kb=$TESTPATH/ring-53.lp --manager=localhost:4999 --packsize=1 --port=5053 --queryplan=$TESTPATH/ring-53.qp --returnplan=$TESTPATH/ring-53.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-54.br --context=54 --kb=$TESTPATH/ring-54.lp --manager=localhost:4999 --packsize=1 --port=5054 --queryplan=$TESTPATH/ring-54.qp --returnplan=$TESTPATH/ring-54.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-55.br --context=55 --kb=$TESTPATH/ring-55.lp --manager=localhost:4999 --packsize=1 --port=5055 --queryplan=$TESTPATH/ring-55.qp --returnplan=$TESTPATH/ring-55.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-56.br --context=56 --kb=$TESTPATH/ring-56.lp --manager=localhost:4999 --packsize=1 --port=5056 --queryplan=$TESTPATH/ring-56.qp --returnplan=$TESTPATH/ring-56.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-57.br --context=57 --kb=$TESTPATH/ring-57.lp --manager=localhost:4999 --packsize=1 --port=5057 --queryplan=$TESTPATH/ring-57.qp --returnplan=$TESTPATH/ring-57.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-58.br --context=58 --kb=$TESTPATH/ring-58.lp --manager=localhost:4999 --packsize=1 --port=5058 --queryplan=$TESTPATH/ring-58.qp --returnplan=$TESTPATH/ring-58.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-59.br --context=59 --kb=$TESTPATH/ring-59.lp --manager=localhost:4999 --packsize=1 --port=5059 --queryplan=$TESTPATH/ring-59.qp --returnplan=$TESTPATH/ring-59.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-60.br --context=60 --kb=$TESTPATH/ring-60.lp --manager=localhost:4999 --packsize=1 --port=5060 --queryplan=$TESTPATH/ring-60.qp --returnplan=$TESTPATH/ring-60.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-61.br --context=61 --kb=$TESTPATH/ring-61.lp --manager=localhost:4999 --packsize=1 --port=5061 --queryplan=$TESTPATH/ring-61.qp --returnplan=$TESTPATH/ring-61.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-62.br --context=62 --kb=$TESTPATH/ring-62.lp --manager=localhost:4999 --packsize=1 --port=5062 --queryplan=$TESTPATH/ring-62.qp --returnplan=$TESTPATH/ring-62.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-63.br --context=63 --kb=$TESTPATH/ring-63.lp --manager=localhost:4999 --packsize=1 --port=5063 --queryplan=$TESTPATH/ring-63.qp --returnplan=$TESTPATH/ring-63.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-64.br --context=64 --kb=$TESTPATH/ring-64.lp --manager=localhost:4999 --packsize=1 --port=5064 --queryplan=$TESTPATH/ring-64.qp --returnplan=$TESTPATH/ring-64.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-65.br --context=65 --kb=$TESTPATH/ring-65.lp --manager=localhost:4999 --packsize=1 --port=5065 --queryplan=$TESTPATH/ring-65.qp --returnplan=$TESTPATH/ring-65.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-66.br --context=66 --kb=$TESTPATH/ring-66.lp --manager=localhost:4999 --packsize=1 --port=5066 --queryplan=$TESTPATH/ring-66.qp --returnplan=$TESTPATH/ring-66.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-67.br --context=67 --kb=$TESTPATH/ring-67.lp --manager=localhost:4999 --packsize=1 --port=5067 --queryplan=$TESTPATH/ring-67.qp --returnplan=$TESTPATH/ring-67.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-68.br --context=68 --kb=$TESTPATH/ring-68.lp --manager=localhost:4999 --packsize=1 --port=5068 --queryplan=$TESTPATH/ring-68.qp --returnplan=$TESTPATH/ring-68.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/ring-69.br --context=69 --kb=$TESTPATH/ring-69.lp --manager=localhost:4999 --packsize=1 --port=5069 --queryplan=$TESTPATH/ring-69.qp --returnplan=$TESTPATH/ring-69.rp --system-size=70  >/dev/null 2>&1 &
sleep 2
sleep 140
/usr/bin/time --verbose -o ring-time.log /usr/bin/timeout -k 20 $TIMEOUT $DMCSPATH/new_dmcsc --hostname=localhost --port=5000 --root=0 --signature=$TESTPATH/client.qp --belief-state-size=10 --k1=1 --k2=1 --loop=0 > ring.log 2> ring-err.log
