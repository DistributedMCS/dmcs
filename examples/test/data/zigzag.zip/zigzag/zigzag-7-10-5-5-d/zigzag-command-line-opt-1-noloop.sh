#!/bin/bash
export TIMEFORMAT=$'\nreal\t%3R\nuser\t%3U\nsys\t%3S'
export TIMEOUT=600
export TESTPATH='.'
export DMCSPATH='../../../../../build/src'
killall new_dmcsd
killall new_dmcsm
sleep 5
$DMCSPATH/new_dmcsm --port=4999 --system-size=7 &
sleep 5
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-0.br --context=0 --kb=$TESTPATH/zigzag-0.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-0.oqp --packsize=1 --port=5000 --queryplan=$TESTPATH/zigzag-0.qp --returnplan=$TESTPATH/zigzag-0.orp --system-size=7  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-1.br --context=1 --kb=$TESTPATH/zigzag-1.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-1.oqp --packsize=1 --port=5001 --queryplan=$TESTPATH/zigzag-1.qp --returnplan=$TESTPATH/zigzag-1.orp --system-size=7  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-2.br --context=2 --kb=$TESTPATH/zigzag-2.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-2.oqp --packsize=1 --port=5002 --queryplan=$TESTPATH/zigzag-2.qp --returnplan=$TESTPATH/zigzag-2.orp --system-size=7  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-3.br --context=3 --kb=$TESTPATH/zigzag-3.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-3.oqp --packsize=1 --port=5003 --queryplan=$TESTPATH/zigzag-3.qp --returnplan=$TESTPATH/zigzag-3.orp --system-size=7  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-4.br --context=4 --kb=$TESTPATH/zigzag-4.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-4.oqp --packsize=1 --port=5004 --queryplan=$TESTPATH/zigzag-4.qp --returnplan=$TESTPATH/zigzag-4.orp --system-size=7  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-5.br --context=5 --kb=$TESTPATH/zigzag-5.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-5.oqp --packsize=1 --port=5005 --queryplan=$TESTPATH/zigzag-5.qp --returnplan=$TESTPATH/zigzag-5.orp --system-size=7  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-6.br --context=6 --kb=$TESTPATH/zigzag-6.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-6.oqp --packsize=1 --port=5006 --queryplan=$TESTPATH/zigzag-6.qp --returnplan=$TESTPATH/zigzag-6.orp --system-size=7  >/dev/null 2>&1 &
sleep 2
sleep 14
/usr/bin/time --verbose -o zigzag-time.log /usr/bin/timeout -k 20 $TIMEOUT $DMCSPATH/new_dmcsc --hostname=localhost --port=5000 --root=0 --signature=$TESTPATH/client.qp --belief-state-size=10 --k1=1 --k2=1 --loop=0 > zigzag.log 2> zigzag-err.log
