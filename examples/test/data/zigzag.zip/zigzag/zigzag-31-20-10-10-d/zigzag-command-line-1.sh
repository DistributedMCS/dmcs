#!/bin/bash
export TIMEFORMAT=$'\nreal\t%3R\nuser\t%3U\nsys\t%3S'
export TIMEOUT=600
export TESTPATH='.'
export DMCSPATH='../../../../../build/src'
killall new_dmcsd
killall new_dmcsm
sleep 5
$DMCSPATH/new_dmcsm --port=4999 --system-size=31 &
sleep 5
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-0.br --context=0 --kb=$TESTPATH/zigzag-0.lp --manager=localhost:4999 --packsize=1 --port=5000 --queryplan=$TESTPATH/zigzag-0.qp --returnplan=$TESTPATH/zigzag-0.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-1.br --context=1 --kb=$TESTPATH/zigzag-1.lp --manager=localhost:4999 --packsize=1 --port=5001 --queryplan=$TESTPATH/zigzag-1.qp --returnplan=$TESTPATH/zigzag-1.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-2.br --context=2 --kb=$TESTPATH/zigzag-2.lp --manager=localhost:4999 --packsize=1 --port=5002 --queryplan=$TESTPATH/zigzag-2.qp --returnplan=$TESTPATH/zigzag-2.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-3.br --context=3 --kb=$TESTPATH/zigzag-3.lp --manager=localhost:4999 --packsize=1 --port=5003 --queryplan=$TESTPATH/zigzag-3.qp --returnplan=$TESTPATH/zigzag-3.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-4.br --context=4 --kb=$TESTPATH/zigzag-4.lp --manager=localhost:4999 --packsize=1 --port=5004 --queryplan=$TESTPATH/zigzag-4.qp --returnplan=$TESTPATH/zigzag-4.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-5.br --context=5 --kb=$TESTPATH/zigzag-5.lp --manager=localhost:4999 --packsize=1 --port=5005 --queryplan=$TESTPATH/zigzag-5.qp --returnplan=$TESTPATH/zigzag-5.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-6.br --context=6 --kb=$TESTPATH/zigzag-6.lp --manager=localhost:4999 --packsize=1 --port=5006 --queryplan=$TESTPATH/zigzag-6.qp --returnplan=$TESTPATH/zigzag-6.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-7.br --context=7 --kb=$TESTPATH/zigzag-7.lp --manager=localhost:4999 --packsize=1 --port=5007 --queryplan=$TESTPATH/zigzag-7.qp --returnplan=$TESTPATH/zigzag-7.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-8.br --context=8 --kb=$TESTPATH/zigzag-8.lp --manager=localhost:4999 --packsize=1 --port=5008 --queryplan=$TESTPATH/zigzag-8.qp --returnplan=$TESTPATH/zigzag-8.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-9.br --context=9 --kb=$TESTPATH/zigzag-9.lp --manager=localhost:4999 --packsize=1 --port=5009 --queryplan=$TESTPATH/zigzag-9.qp --returnplan=$TESTPATH/zigzag-9.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-10.br --context=10 --kb=$TESTPATH/zigzag-10.lp --manager=localhost:4999 --packsize=1 --port=5010 --queryplan=$TESTPATH/zigzag-10.qp --returnplan=$TESTPATH/zigzag-10.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-11.br --context=11 --kb=$TESTPATH/zigzag-11.lp --manager=localhost:4999 --packsize=1 --port=5011 --queryplan=$TESTPATH/zigzag-11.qp --returnplan=$TESTPATH/zigzag-11.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-12.br --context=12 --kb=$TESTPATH/zigzag-12.lp --manager=localhost:4999 --packsize=1 --port=5012 --queryplan=$TESTPATH/zigzag-12.qp --returnplan=$TESTPATH/zigzag-12.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-13.br --context=13 --kb=$TESTPATH/zigzag-13.lp --manager=localhost:4999 --packsize=1 --port=5013 --queryplan=$TESTPATH/zigzag-13.qp --returnplan=$TESTPATH/zigzag-13.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-14.br --context=14 --kb=$TESTPATH/zigzag-14.lp --manager=localhost:4999 --packsize=1 --port=5014 --queryplan=$TESTPATH/zigzag-14.qp --returnplan=$TESTPATH/zigzag-14.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-15.br --context=15 --kb=$TESTPATH/zigzag-15.lp --manager=localhost:4999 --packsize=1 --port=5015 --queryplan=$TESTPATH/zigzag-15.qp --returnplan=$TESTPATH/zigzag-15.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-16.br --context=16 --kb=$TESTPATH/zigzag-16.lp --manager=localhost:4999 --packsize=1 --port=5016 --queryplan=$TESTPATH/zigzag-16.qp --returnplan=$TESTPATH/zigzag-16.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-17.br --context=17 --kb=$TESTPATH/zigzag-17.lp --manager=localhost:4999 --packsize=1 --port=5017 --queryplan=$TESTPATH/zigzag-17.qp --returnplan=$TESTPATH/zigzag-17.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-18.br --context=18 --kb=$TESTPATH/zigzag-18.lp --manager=localhost:4999 --packsize=1 --port=5018 --queryplan=$TESTPATH/zigzag-18.qp --returnplan=$TESTPATH/zigzag-18.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-19.br --context=19 --kb=$TESTPATH/zigzag-19.lp --manager=localhost:4999 --packsize=1 --port=5019 --queryplan=$TESTPATH/zigzag-19.qp --returnplan=$TESTPATH/zigzag-19.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-20.br --context=20 --kb=$TESTPATH/zigzag-20.lp --manager=localhost:4999 --packsize=1 --port=5020 --queryplan=$TESTPATH/zigzag-20.qp --returnplan=$TESTPATH/zigzag-20.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-21.br --context=21 --kb=$TESTPATH/zigzag-21.lp --manager=localhost:4999 --packsize=1 --port=5021 --queryplan=$TESTPATH/zigzag-21.qp --returnplan=$TESTPATH/zigzag-21.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-22.br --context=22 --kb=$TESTPATH/zigzag-22.lp --manager=localhost:4999 --packsize=1 --port=5022 --queryplan=$TESTPATH/zigzag-22.qp --returnplan=$TESTPATH/zigzag-22.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-23.br --context=23 --kb=$TESTPATH/zigzag-23.lp --manager=localhost:4999 --packsize=1 --port=5023 --queryplan=$TESTPATH/zigzag-23.qp --returnplan=$TESTPATH/zigzag-23.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-24.br --context=24 --kb=$TESTPATH/zigzag-24.lp --manager=localhost:4999 --packsize=1 --port=5024 --queryplan=$TESTPATH/zigzag-24.qp --returnplan=$TESTPATH/zigzag-24.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-25.br --context=25 --kb=$TESTPATH/zigzag-25.lp --manager=localhost:4999 --packsize=1 --port=5025 --queryplan=$TESTPATH/zigzag-25.qp --returnplan=$TESTPATH/zigzag-25.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-26.br --context=26 --kb=$TESTPATH/zigzag-26.lp --manager=localhost:4999 --packsize=1 --port=5026 --queryplan=$TESTPATH/zigzag-26.qp --returnplan=$TESTPATH/zigzag-26.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-27.br --context=27 --kb=$TESTPATH/zigzag-27.lp --manager=localhost:4999 --packsize=1 --port=5027 --queryplan=$TESTPATH/zigzag-27.qp --returnplan=$TESTPATH/zigzag-27.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-28.br --context=28 --kb=$TESTPATH/zigzag-28.lp --manager=localhost:4999 --packsize=1 --port=5028 --queryplan=$TESTPATH/zigzag-28.qp --returnplan=$TESTPATH/zigzag-28.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-29.br --context=29 --kb=$TESTPATH/zigzag-29.lp --manager=localhost:4999 --packsize=1 --port=5029 --queryplan=$TESTPATH/zigzag-29.qp --returnplan=$TESTPATH/zigzag-29.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-30.br --context=30 --kb=$TESTPATH/zigzag-30.lp --manager=localhost:4999 --packsize=1 --port=5030 --queryplan=$TESTPATH/zigzag-30.qp --returnplan=$TESTPATH/zigzag-30.rp --system-size=31  >/dev/null 2>&1 &
sleep 2
sleep 62
/usr/bin/time --verbose -o zigzag-time.log /usr/bin/timeout -k 20 $TIMEOUT $DMCSPATH/new_dmcsc --hostname=localhost --port=5000 --root=0 --signature=$TESTPATH/client.qp --belief-state-size=20 --k1=1 --k2=1 --loop=1 > zigzag.log 2> zigzag-err.log
