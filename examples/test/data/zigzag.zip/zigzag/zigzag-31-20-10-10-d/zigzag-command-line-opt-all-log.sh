#!/bin/bash
export TIMEFORMAT=$'\nreal\t%3R\nuser\t%3U\nsys\t%3S'
export TIMEOUT=600
export TESTPATH='.'
export DMCSPATH='../../../../../build/src'
killall new_dmcsd
killall new_dmcsm
sleep 5
$DMCSPATH/new_dmcsm --port=4999 --system-size=31 &
sleep 5
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-0.br --context=0 --kb=$TESTPATH/zigzag-0.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-0.oqp --packsize=0 --port=5000 --queryplan=$TESTPATH/zigzag-0.qp --returnplan=$TESTPATH/zigzag-0.orp --system-size=31  >zigzag-0.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-1.br --context=1 --kb=$TESTPATH/zigzag-1.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-1.oqp --packsize=0 --port=5001 --queryplan=$TESTPATH/zigzag-1.qp --returnplan=$TESTPATH/zigzag-1.orp --system-size=31  >zigzag-1.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-2.br --context=2 --kb=$TESTPATH/zigzag-2.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-2.oqp --packsize=0 --port=5002 --queryplan=$TESTPATH/zigzag-2.qp --returnplan=$TESTPATH/zigzag-2.orp --system-size=31  >zigzag-2.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-3.br --context=3 --kb=$TESTPATH/zigzag-3.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-3.oqp --packsize=0 --port=5003 --queryplan=$TESTPATH/zigzag-3.qp --returnplan=$TESTPATH/zigzag-3.orp --system-size=31  >zigzag-3.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-4.br --context=4 --kb=$TESTPATH/zigzag-4.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-4.oqp --packsize=0 --port=5004 --queryplan=$TESTPATH/zigzag-4.qp --returnplan=$TESTPATH/zigzag-4.orp --system-size=31  >zigzag-4.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-5.br --context=5 --kb=$TESTPATH/zigzag-5.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-5.oqp --packsize=0 --port=5005 --queryplan=$TESTPATH/zigzag-5.qp --returnplan=$TESTPATH/zigzag-5.orp --system-size=31  >zigzag-5.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-6.br --context=6 --kb=$TESTPATH/zigzag-6.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-6.oqp --packsize=0 --port=5006 --queryplan=$TESTPATH/zigzag-6.qp --returnplan=$TESTPATH/zigzag-6.orp --system-size=31  >zigzag-6.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-7.br --context=7 --kb=$TESTPATH/zigzag-7.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-7.oqp --packsize=0 --port=5007 --queryplan=$TESTPATH/zigzag-7.qp --returnplan=$TESTPATH/zigzag-7.orp --system-size=31  >zigzag-7.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-8.br --context=8 --kb=$TESTPATH/zigzag-8.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-8.oqp --packsize=0 --port=5008 --queryplan=$TESTPATH/zigzag-8.qp --returnplan=$TESTPATH/zigzag-8.orp --system-size=31  >zigzag-8.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-9.br --context=9 --kb=$TESTPATH/zigzag-9.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-9.oqp --packsize=0 --port=5009 --queryplan=$TESTPATH/zigzag-9.qp --returnplan=$TESTPATH/zigzag-9.orp --system-size=31  >zigzag-9.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-10.br --context=10 --kb=$TESTPATH/zigzag-10.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-10.oqp --packsize=0 --port=5010 --queryplan=$TESTPATH/zigzag-10.qp --returnplan=$TESTPATH/zigzag-10.orp --system-size=31  >zigzag-10.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-11.br --context=11 --kb=$TESTPATH/zigzag-11.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-11.oqp --packsize=0 --port=5011 --queryplan=$TESTPATH/zigzag-11.qp --returnplan=$TESTPATH/zigzag-11.orp --system-size=31  >zigzag-11.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-12.br --context=12 --kb=$TESTPATH/zigzag-12.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-12.oqp --packsize=0 --port=5012 --queryplan=$TESTPATH/zigzag-12.qp --returnplan=$TESTPATH/zigzag-12.orp --system-size=31  >zigzag-12.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-13.br --context=13 --kb=$TESTPATH/zigzag-13.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-13.oqp --packsize=0 --port=5013 --queryplan=$TESTPATH/zigzag-13.qp --returnplan=$TESTPATH/zigzag-13.orp --system-size=31  >zigzag-13.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-14.br --context=14 --kb=$TESTPATH/zigzag-14.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-14.oqp --packsize=0 --port=5014 --queryplan=$TESTPATH/zigzag-14.qp --returnplan=$TESTPATH/zigzag-14.orp --system-size=31  >zigzag-14.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-15.br --context=15 --kb=$TESTPATH/zigzag-15.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-15.oqp --packsize=0 --port=5015 --queryplan=$TESTPATH/zigzag-15.qp --returnplan=$TESTPATH/zigzag-15.orp --system-size=31  >zigzag-15.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-16.br --context=16 --kb=$TESTPATH/zigzag-16.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-16.oqp --packsize=0 --port=5016 --queryplan=$TESTPATH/zigzag-16.qp --returnplan=$TESTPATH/zigzag-16.orp --system-size=31  >zigzag-16.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-17.br --context=17 --kb=$TESTPATH/zigzag-17.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-17.oqp --packsize=0 --port=5017 --queryplan=$TESTPATH/zigzag-17.qp --returnplan=$TESTPATH/zigzag-17.orp --system-size=31  >zigzag-17.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-18.br --context=18 --kb=$TESTPATH/zigzag-18.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-18.oqp --packsize=0 --port=5018 --queryplan=$TESTPATH/zigzag-18.qp --returnplan=$TESTPATH/zigzag-18.orp --system-size=31  >zigzag-18.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-19.br --context=19 --kb=$TESTPATH/zigzag-19.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-19.oqp --packsize=0 --port=5019 --queryplan=$TESTPATH/zigzag-19.qp --returnplan=$TESTPATH/zigzag-19.orp --system-size=31  >zigzag-19.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-20.br --context=20 --kb=$TESTPATH/zigzag-20.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-20.oqp --packsize=0 --port=5020 --queryplan=$TESTPATH/zigzag-20.qp --returnplan=$TESTPATH/zigzag-20.orp --system-size=31  >zigzag-20.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-21.br --context=21 --kb=$TESTPATH/zigzag-21.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-21.oqp --packsize=0 --port=5021 --queryplan=$TESTPATH/zigzag-21.qp --returnplan=$TESTPATH/zigzag-21.orp --system-size=31  >zigzag-21.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-22.br --context=22 --kb=$TESTPATH/zigzag-22.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-22.oqp --packsize=0 --port=5022 --queryplan=$TESTPATH/zigzag-22.qp --returnplan=$TESTPATH/zigzag-22.orp --system-size=31  >zigzag-22.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-23.br --context=23 --kb=$TESTPATH/zigzag-23.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-23.oqp --packsize=0 --port=5023 --queryplan=$TESTPATH/zigzag-23.qp --returnplan=$TESTPATH/zigzag-23.orp --system-size=31  >zigzag-23.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-24.br --context=24 --kb=$TESTPATH/zigzag-24.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-24.oqp --packsize=0 --port=5024 --queryplan=$TESTPATH/zigzag-24.qp --returnplan=$TESTPATH/zigzag-24.orp --system-size=31  >zigzag-24.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-25.br --context=25 --kb=$TESTPATH/zigzag-25.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-25.oqp --packsize=0 --port=5025 --queryplan=$TESTPATH/zigzag-25.qp --returnplan=$TESTPATH/zigzag-25.orp --system-size=31  >zigzag-25.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-26.br --context=26 --kb=$TESTPATH/zigzag-26.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-26.oqp --packsize=0 --port=5026 --queryplan=$TESTPATH/zigzag-26.qp --returnplan=$TESTPATH/zigzag-26.orp --system-size=31  >zigzag-26.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-27.br --context=27 --kb=$TESTPATH/zigzag-27.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-27.oqp --packsize=0 --port=5027 --queryplan=$TESTPATH/zigzag-27.qp --returnplan=$TESTPATH/zigzag-27.orp --system-size=31  >zigzag-27.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-28.br --context=28 --kb=$TESTPATH/zigzag-28.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-28.oqp --packsize=0 --port=5028 --queryplan=$TESTPATH/zigzag-28.qp --returnplan=$TESTPATH/zigzag-28.orp --system-size=31  >zigzag-28.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-29.br --context=29 --kb=$TESTPATH/zigzag-29.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-29.oqp --packsize=0 --port=5029 --queryplan=$TESTPATH/zigzag-29.qp --returnplan=$TESTPATH/zigzag-29.orp --system-size=31  >zigzag-29.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/zigzag-30.br --context=30 --kb=$TESTPATH/zigzag-30.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/zigzag-30.oqp --packsize=0 --port=5030 --queryplan=$TESTPATH/zigzag-30.qp --returnplan=$TESTPATH/zigzag-30.orp --system-size=31  >zigzag-30.log 2>&1 &
sleep 2
sleep 62
/usr/bin/time --verbose -o zigzag-time.log /usr/bin/timeout -k 20 $TIMEOUT $DMCSPATH/new_dmcsc --hostname=localhost --port=5000 --root=0 --signature=$TESTPATH/client.qp --belief-state-size=20 --k1=0 --k2=0 --loop=1 > zigzag.log 2> zigzag-err.log
