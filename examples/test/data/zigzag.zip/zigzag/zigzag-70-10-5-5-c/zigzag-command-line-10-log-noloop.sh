#!/bin/bash
export TIMEFORMAT=$'\nreal\t%3R\nuser\t%3U\nsys\t%3S'
export TIMEOUT=600
export TESTPATH='.'
export DMCSPATH='../../../../../build/src'
killall new_dmcsd
killall new_dmcsm
sleep 5
$DMCSPATH/new_dmcsm --port=4999 --system-size=70 &
sleep 5
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-0.br --context=0 --kb=$TESTPATH/zigzag-0.lp --manager=localhost:4999 --packsize=10 --port=5000 --queryplan=$TESTPATH/zigzag-0.qp --returnplan=$TESTPATH/zigzag-0.rp --system-size=70  >zigzag-0.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-1.br --context=1 --kb=$TESTPATH/zigzag-1.lp --manager=localhost:4999 --packsize=10 --port=5001 --queryplan=$TESTPATH/zigzag-1.qp --returnplan=$TESTPATH/zigzag-1.rp --system-size=70  >zigzag-1.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-2.br --context=2 --kb=$TESTPATH/zigzag-2.lp --manager=localhost:4999 --packsize=10 --port=5002 --queryplan=$TESTPATH/zigzag-2.qp --returnplan=$TESTPATH/zigzag-2.rp --system-size=70  >zigzag-2.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-3.br --context=3 --kb=$TESTPATH/zigzag-3.lp --manager=localhost:4999 --packsize=10 --port=5003 --queryplan=$TESTPATH/zigzag-3.qp --returnplan=$TESTPATH/zigzag-3.rp --system-size=70  >zigzag-3.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-4.br --context=4 --kb=$TESTPATH/zigzag-4.lp --manager=localhost:4999 --packsize=10 --port=5004 --queryplan=$TESTPATH/zigzag-4.qp --returnplan=$TESTPATH/zigzag-4.rp --system-size=70  >zigzag-4.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-5.br --context=5 --kb=$TESTPATH/zigzag-5.lp --manager=localhost:4999 --packsize=10 --port=5005 --queryplan=$TESTPATH/zigzag-5.qp --returnplan=$TESTPATH/zigzag-5.rp --system-size=70  >zigzag-5.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-6.br --context=6 --kb=$TESTPATH/zigzag-6.lp --manager=localhost:4999 --packsize=10 --port=5006 --queryplan=$TESTPATH/zigzag-6.qp --returnplan=$TESTPATH/zigzag-6.rp --system-size=70  >zigzag-6.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-7.br --context=7 --kb=$TESTPATH/zigzag-7.lp --manager=localhost:4999 --packsize=10 --port=5007 --queryplan=$TESTPATH/zigzag-7.qp --returnplan=$TESTPATH/zigzag-7.rp --system-size=70  >zigzag-7.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-8.br --context=8 --kb=$TESTPATH/zigzag-8.lp --manager=localhost:4999 --packsize=10 --port=5008 --queryplan=$TESTPATH/zigzag-8.qp --returnplan=$TESTPATH/zigzag-8.rp --system-size=70  >zigzag-8.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-9.br --context=9 --kb=$TESTPATH/zigzag-9.lp --manager=localhost:4999 --packsize=10 --port=5009 --queryplan=$TESTPATH/zigzag-9.qp --returnplan=$TESTPATH/zigzag-9.rp --system-size=70  >zigzag-9.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-10.br --context=10 --kb=$TESTPATH/zigzag-10.lp --manager=localhost:4999 --packsize=10 --port=5010 --queryplan=$TESTPATH/zigzag-10.qp --returnplan=$TESTPATH/zigzag-10.rp --system-size=70  >zigzag-10.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-11.br --context=11 --kb=$TESTPATH/zigzag-11.lp --manager=localhost:4999 --packsize=10 --port=5011 --queryplan=$TESTPATH/zigzag-11.qp --returnplan=$TESTPATH/zigzag-11.rp --system-size=70  >zigzag-11.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-12.br --context=12 --kb=$TESTPATH/zigzag-12.lp --manager=localhost:4999 --packsize=10 --port=5012 --queryplan=$TESTPATH/zigzag-12.qp --returnplan=$TESTPATH/zigzag-12.rp --system-size=70  >zigzag-12.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-13.br --context=13 --kb=$TESTPATH/zigzag-13.lp --manager=localhost:4999 --packsize=10 --port=5013 --queryplan=$TESTPATH/zigzag-13.qp --returnplan=$TESTPATH/zigzag-13.rp --system-size=70  >zigzag-13.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-14.br --context=14 --kb=$TESTPATH/zigzag-14.lp --manager=localhost:4999 --packsize=10 --port=5014 --queryplan=$TESTPATH/zigzag-14.qp --returnplan=$TESTPATH/zigzag-14.rp --system-size=70  >zigzag-14.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-15.br --context=15 --kb=$TESTPATH/zigzag-15.lp --manager=localhost:4999 --packsize=10 --port=5015 --queryplan=$TESTPATH/zigzag-15.qp --returnplan=$TESTPATH/zigzag-15.rp --system-size=70  >zigzag-15.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-16.br --context=16 --kb=$TESTPATH/zigzag-16.lp --manager=localhost:4999 --packsize=10 --port=5016 --queryplan=$TESTPATH/zigzag-16.qp --returnplan=$TESTPATH/zigzag-16.rp --system-size=70  >zigzag-16.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-17.br --context=17 --kb=$TESTPATH/zigzag-17.lp --manager=localhost:4999 --packsize=10 --port=5017 --queryplan=$TESTPATH/zigzag-17.qp --returnplan=$TESTPATH/zigzag-17.rp --system-size=70  >zigzag-17.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-18.br --context=18 --kb=$TESTPATH/zigzag-18.lp --manager=localhost:4999 --packsize=10 --port=5018 --queryplan=$TESTPATH/zigzag-18.qp --returnplan=$TESTPATH/zigzag-18.rp --system-size=70  >zigzag-18.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-19.br --context=19 --kb=$TESTPATH/zigzag-19.lp --manager=localhost:4999 --packsize=10 --port=5019 --queryplan=$TESTPATH/zigzag-19.qp --returnplan=$TESTPATH/zigzag-19.rp --system-size=70  >zigzag-19.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-20.br --context=20 --kb=$TESTPATH/zigzag-20.lp --manager=localhost:4999 --packsize=10 --port=5020 --queryplan=$TESTPATH/zigzag-20.qp --returnplan=$TESTPATH/zigzag-20.rp --system-size=70  >zigzag-20.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-21.br --context=21 --kb=$TESTPATH/zigzag-21.lp --manager=localhost:4999 --packsize=10 --port=5021 --queryplan=$TESTPATH/zigzag-21.qp --returnplan=$TESTPATH/zigzag-21.rp --system-size=70  >zigzag-21.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-22.br --context=22 --kb=$TESTPATH/zigzag-22.lp --manager=localhost:4999 --packsize=10 --port=5022 --queryplan=$TESTPATH/zigzag-22.qp --returnplan=$TESTPATH/zigzag-22.rp --system-size=70  >zigzag-22.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-23.br --context=23 --kb=$TESTPATH/zigzag-23.lp --manager=localhost:4999 --packsize=10 --port=5023 --queryplan=$TESTPATH/zigzag-23.qp --returnplan=$TESTPATH/zigzag-23.rp --system-size=70  >zigzag-23.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-24.br --context=24 --kb=$TESTPATH/zigzag-24.lp --manager=localhost:4999 --packsize=10 --port=5024 --queryplan=$TESTPATH/zigzag-24.qp --returnplan=$TESTPATH/zigzag-24.rp --system-size=70  >zigzag-24.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-25.br --context=25 --kb=$TESTPATH/zigzag-25.lp --manager=localhost:4999 --packsize=10 --port=5025 --queryplan=$TESTPATH/zigzag-25.qp --returnplan=$TESTPATH/zigzag-25.rp --system-size=70  >zigzag-25.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-26.br --context=26 --kb=$TESTPATH/zigzag-26.lp --manager=localhost:4999 --packsize=10 --port=5026 --queryplan=$TESTPATH/zigzag-26.qp --returnplan=$TESTPATH/zigzag-26.rp --system-size=70  >zigzag-26.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-27.br --context=27 --kb=$TESTPATH/zigzag-27.lp --manager=localhost:4999 --packsize=10 --port=5027 --queryplan=$TESTPATH/zigzag-27.qp --returnplan=$TESTPATH/zigzag-27.rp --system-size=70  >zigzag-27.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-28.br --context=28 --kb=$TESTPATH/zigzag-28.lp --manager=localhost:4999 --packsize=10 --port=5028 --queryplan=$TESTPATH/zigzag-28.qp --returnplan=$TESTPATH/zigzag-28.rp --system-size=70  >zigzag-28.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-29.br --context=29 --kb=$TESTPATH/zigzag-29.lp --manager=localhost:4999 --packsize=10 --port=5029 --queryplan=$TESTPATH/zigzag-29.qp --returnplan=$TESTPATH/zigzag-29.rp --system-size=70  >zigzag-29.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-30.br --context=30 --kb=$TESTPATH/zigzag-30.lp --manager=localhost:4999 --packsize=10 --port=5030 --queryplan=$TESTPATH/zigzag-30.qp --returnplan=$TESTPATH/zigzag-30.rp --system-size=70  >zigzag-30.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-31.br --context=31 --kb=$TESTPATH/zigzag-31.lp --manager=localhost:4999 --packsize=10 --port=5031 --queryplan=$TESTPATH/zigzag-31.qp --returnplan=$TESTPATH/zigzag-31.rp --system-size=70  >zigzag-31.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-32.br --context=32 --kb=$TESTPATH/zigzag-32.lp --manager=localhost:4999 --packsize=10 --port=5032 --queryplan=$TESTPATH/zigzag-32.qp --returnplan=$TESTPATH/zigzag-32.rp --system-size=70  >zigzag-32.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-33.br --context=33 --kb=$TESTPATH/zigzag-33.lp --manager=localhost:4999 --packsize=10 --port=5033 --queryplan=$TESTPATH/zigzag-33.qp --returnplan=$TESTPATH/zigzag-33.rp --system-size=70  >zigzag-33.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-34.br --context=34 --kb=$TESTPATH/zigzag-34.lp --manager=localhost:4999 --packsize=10 --port=5034 --queryplan=$TESTPATH/zigzag-34.qp --returnplan=$TESTPATH/zigzag-34.rp --system-size=70  >zigzag-34.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-35.br --context=35 --kb=$TESTPATH/zigzag-35.lp --manager=localhost:4999 --packsize=10 --port=5035 --queryplan=$TESTPATH/zigzag-35.qp --returnplan=$TESTPATH/zigzag-35.rp --system-size=70  >zigzag-35.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-36.br --context=36 --kb=$TESTPATH/zigzag-36.lp --manager=localhost:4999 --packsize=10 --port=5036 --queryplan=$TESTPATH/zigzag-36.qp --returnplan=$TESTPATH/zigzag-36.rp --system-size=70  >zigzag-36.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-37.br --context=37 --kb=$TESTPATH/zigzag-37.lp --manager=localhost:4999 --packsize=10 --port=5037 --queryplan=$TESTPATH/zigzag-37.qp --returnplan=$TESTPATH/zigzag-37.rp --system-size=70  >zigzag-37.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-38.br --context=38 --kb=$TESTPATH/zigzag-38.lp --manager=localhost:4999 --packsize=10 --port=5038 --queryplan=$TESTPATH/zigzag-38.qp --returnplan=$TESTPATH/zigzag-38.rp --system-size=70  >zigzag-38.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-39.br --context=39 --kb=$TESTPATH/zigzag-39.lp --manager=localhost:4999 --packsize=10 --port=5039 --queryplan=$TESTPATH/zigzag-39.qp --returnplan=$TESTPATH/zigzag-39.rp --system-size=70  >zigzag-39.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-40.br --context=40 --kb=$TESTPATH/zigzag-40.lp --manager=localhost:4999 --packsize=10 --port=5040 --queryplan=$TESTPATH/zigzag-40.qp --returnplan=$TESTPATH/zigzag-40.rp --system-size=70  >zigzag-40.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-41.br --context=41 --kb=$TESTPATH/zigzag-41.lp --manager=localhost:4999 --packsize=10 --port=5041 --queryplan=$TESTPATH/zigzag-41.qp --returnplan=$TESTPATH/zigzag-41.rp --system-size=70  >zigzag-41.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-42.br --context=42 --kb=$TESTPATH/zigzag-42.lp --manager=localhost:4999 --packsize=10 --port=5042 --queryplan=$TESTPATH/zigzag-42.qp --returnplan=$TESTPATH/zigzag-42.rp --system-size=70  >zigzag-42.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-43.br --context=43 --kb=$TESTPATH/zigzag-43.lp --manager=localhost:4999 --packsize=10 --port=5043 --queryplan=$TESTPATH/zigzag-43.qp --returnplan=$TESTPATH/zigzag-43.rp --system-size=70  >zigzag-43.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-44.br --context=44 --kb=$TESTPATH/zigzag-44.lp --manager=localhost:4999 --packsize=10 --port=5044 --queryplan=$TESTPATH/zigzag-44.qp --returnplan=$TESTPATH/zigzag-44.rp --system-size=70  >zigzag-44.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-45.br --context=45 --kb=$TESTPATH/zigzag-45.lp --manager=localhost:4999 --packsize=10 --port=5045 --queryplan=$TESTPATH/zigzag-45.qp --returnplan=$TESTPATH/zigzag-45.rp --system-size=70  >zigzag-45.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-46.br --context=46 --kb=$TESTPATH/zigzag-46.lp --manager=localhost:4999 --packsize=10 --port=5046 --queryplan=$TESTPATH/zigzag-46.qp --returnplan=$TESTPATH/zigzag-46.rp --system-size=70  >zigzag-46.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-47.br --context=47 --kb=$TESTPATH/zigzag-47.lp --manager=localhost:4999 --packsize=10 --port=5047 --queryplan=$TESTPATH/zigzag-47.qp --returnplan=$TESTPATH/zigzag-47.rp --system-size=70  >zigzag-47.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-48.br --context=48 --kb=$TESTPATH/zigzag-48.lp --manager=localhost:4999 --packsize=10 --port=5048 --queryplan=$TESTPATH/zigzag-48.qp --returnplan=$TESTPATH/zigzag-48.rp --system-size=70  >zigzag-48.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-49.br --context=49 --kb=$TESTPATH/zigzag-49.lp --manager=localhost:4999 --packsize=10 --port=5049 --queryplan=$TESTPATH/zigzag-49.qp --returnplan=$TESTPATH/zigzag-49.rp --system-size=70  >zigzag-49.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-50.br --context=50 --kb=$TESTPATH/zigzag-50.lp --manager=localhost:4999 --packsize=10 --port=5050 --queryplan=$TESTPATH/zigzag-50.qp --returnplan=$TESTPATH/zigzag-50.rp --system-size=70  >zigzag-50.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-51.br --context=51 --kb=$TESTPATH/zigzag-51.lp --manager=localhost:4999 --packsize=10 --port=5051 --queryplan=$TESTPATH/zigzag-51.qp --returnplan=$TESTPATH/zigzag-51.rp --system-size=70  >zigzag-51.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-52.br --context=52 --kb=$TESTPATH/zigzag-52.lp --manager=localhost:4999 --packsize=10 --port=5052 --queryplan=$TESTPATH/zigzag-52.qp --returnplan=$TESTPATH/zigzag-52.rp --system-size=70  >zigzag-52.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-53.br --context=53 --kb=$TESTPATH/zigzag-53.lp --manager=localhost:4999 --packsize=10 --port=5053 --queryplan=$TESTPATH/zigzag-53.qp --returnplan=$TESTPATH/zigzag-53.rp --system-size=70  >zigzag-53.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-54.br --context=54 --kb=$TESTPATH/zigzag-54.lp --manager=localhost:4999 --packsize=10 --port=5054 --queryplan=$TESTPATH/zigzag-54.qp --returnplan=$TESTPATH/zigzag-54.rp --system-size=70  >zigzag-54.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-55.br --context=55 --kb=$TESTPATH/zigzag-55.lp --manager=localhost:4999 --packsize=10 --port=5055 --queryplan=$TESTPATH/zigzag-55.qp --returnplan=$TESTPATH/zigzag-55.rp --system-size=70  >zigzag-55.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-56.br --context=56 --kb=$TESTPATH/zigzag-56.lp --manager=localhost:4999 --packsize=10 --port=5056 --queryplan=$TESTPATH/zigzag-56.qp --returnplan=$TESTPATH/zigzag-56.rp --system-size=70  >zigzag-56.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-57.br --context=57 --kb=$TESTPATH/zigzag-57.lp --manager=localhost:4999 --packsize=10 --port=5057 --queryplan=$TESTPATH/zigzag-57.qp --returnplan=$TESTPATH/zigzag-57.rp --system-size=70  >zigzag-57.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-58.br --context=58 --kb=$TESTPATH/zigzag-58.lp --manager=localhost:4999 --packsize=10 --port=5058 --queryplan=$TESTPATH/zigzag-58.qp --returnplan=$TESTPATH/zigzag-58.rp --system-size=70  >zigzag-58.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-59.br --context=59 --kb=$TESTPATH/zigzag-59.lp --manager=localhost:4999 --packsize=10 --port=5059 --queryplan=$TESTPATH/zigzag-59.qp --returnplan=$TESTPATH/zigzag-59.rp --system-size=70  >zigzag-59.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-60.br --context=60 --kb=$TESTPATH/zigzag-60.lp --manager=localhost:4999 --packsize=10 --port=5060 --queryplan=$TESTPATH/zigzag-60.qp --returnplan=$TESTPATH/zigzag-60.rp --system-size=70  >zigzag-60.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-61.br --context=61 --kb=$TESTPATH/zigzag-61.lp --manager=localhost:4999 --packsize=10 --port=5061 --queryplan=$TESTPATH/zigzag-61.qp --returnplan=$TESTPATH/zigzag-61.rp --system-size=70  >zigzag-61.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-62.br --context=62 --kb=$TESTPATH/zigzag-62.lp --manager=localhost:4999 --packsize=10 --port=5062 --queryplan=$TESTPATH/zigzag-62.qp --returnplan=$TESTPATH/zigzag-62.rp --system-size=70  >zigzag-62.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-63.br --context=63 --kb=$TESTPATH/zigzag-63.lp --manager=localhost:4999 --packsize=10 --port=5063 --queryplan=$TESTPATH/zigzag-63.qp --returnplan=$TESTPATH/zigzag-63.rp --system-size=70  >zigzag-63.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-64.br --context=64 --kb=$TESTPATH/zigzag-64.lp --manager=localhost:4999 --packsize=10 --port=5064 --queryplan=$TESTPATH/zigzag-64.qp --returnplan=$TESTPATH/zigzag-64.rp --system-size=70  >zigzag-64.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-65.br --context=65 --kb=$TESTPATH/zigzag-65.lp --manager=localhost:4999 --packsize=10 --port=5065 --queryplan=$TESTPATH/zigzag-65.qp --returnplan=$TESTPATH/zigzag-65.rp --system-size=70  >zigzag-65.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-66.br --context=66 --kb=$TESTPATH/zigzag-66.lp --manager=localhost:4999 --packsize=10 --port=5066 --queryplan=$TESTPATH/zigzag-66.qp --returnplan=$TESTPATH/zigzag-66.rp --system-size=70  >zigzag-66.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-67.br --context=67 --kb=$TESTPATH/zigzag-67.lp --manager=localhost:4999 --packsize=10 --port=5067 --queryplan=$TESTPATH/zigzag-67.qp --returnplan=$TESTPATH/zigzag-67.rp --system-size=70  >zigzag-67.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-68.br --context=68 --kb=$TESTPATH/zigzag-68.lp --manager=localhost:4999 --packsize=10 --port=5068 --queryplan=$TESTPATH/zigzag-68.qp --returnplan=$TESTPATH/zigzag-68.rp --system-size=70  >zigzag-68.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=10 --br=$TESTPATH/zigzag-69.br --context=69 --kb=$TESTPATH/zigzag-69.lp --manager=localhost:4999 --packsize=10 --port=5069 --queryplan=$TESTPATH/zigzag-69.qp --returnplan=$TESTPATH/zigzag-69.rp --system-size=70  >zigzag-69.log 2>&1 &
sleep 2
sleep 140
/usr/bin/time --verbose -o zigzag-time.log /usr/bin/timeout -k 20 $TIMEOUT $DMCSPATH/new_dmcsc --hostname=localhost --port=5000 --root=0 --signature=$TESTPATH/client.qp --belief-state-size=10 --k1=1 --k2=10 --loop=0 > zigzag.log 2> zigzag-err.log
