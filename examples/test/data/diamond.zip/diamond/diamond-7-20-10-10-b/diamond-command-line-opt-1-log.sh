#!/bin/bash
export TIMEFORMAT=$'\nreal\t%3R\nuser\t%3U\nsys\t%3S'
export TIMEOUT=600
export TESTPATH='.'
export DMCSPATH='../../../../../build/src'
killall new_dmcsd
killall new_dmcsm
sleep 5
$DMCSPATH/new_dmcsm --port=4999 --system-size=7 &
sleep 5
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/diamond-0.br --context=0 --kb=$TESTPATH/diamond-0.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/diamond-0.oqp --packsize=1 --port=5000 --queryplan=$TESTPATH/diamond-0.qp --returnplan=$TESTPATH/diamond-0.orp --system-size=7  >diamond-0.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/diamond-1.br --context=1 --kb=$TESTPATH/diamond-1.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/diamond-1.oqp --packsize=1 --port=5001 --queryplan=$TESTPATH/diamond-1.qp --returnplan=$TESTPATH/diamond-1.orp --system-size=7  >diamond-1.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/diamond-2.br --context=2 --kb=$TESTPATH/diamond-2.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/diamond-2.oqp --packsize=1 --port=5002 --queryplan=$TESTPATH/diamond-2.qp --returnplan=$TESTPATH/diamond-2.orp --system-size=7  >diamond-2.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/diamond-3.br --context=3 --kb=$TESTPATH/diamond-3.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/diamond-3.oqp --packsize=1 --port=5003 --queryplan=$TESTPATH/diamond-3.qp --returnplan=$TESTPATH/diamond-3.orp --system-size=7  >diamond-3.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/diamond-4.br --context=4 --kb=$TESTPATH/diamond-4.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/diamond-4.oqp --packsize=1 --port=5004 --queryplan=$TESTPATH/diamond-4.qp --returnplan=$TESTPATH/diamond-4.orp --system-size=7  >diamond-4.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/diamond-5.br --context=5 --kb=$TESTPATH/diamond-5.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/diamond-5.oqp --packsize=1 --port=5005 --queryplan=$TESTPATH/diamond-5.qp --returnplan=$TESTPATH/diamond-5.orp --system-size=7  >diamond-5.log 2>&1 &
sleep 2
$DMCSPATH/new_dmcsd --belief-state-size=20 --br=$TESTPATH/diamond-6.br --context=6 --kb=$TESTPATH/diamond-6.lp --manager=localhost:4999 --optqueryplan=$TESTPATH/diamond-6.oqp --packsize=1 --port=5006 --queryplan=$TESTPATH/diamond-6.qp --returnplan=$TESTPATH/diamond-6.orp --system-size=7  >diamond-6.log 2>&1 &
sleep 2
sleep 14
/usr/bin/time --verbose -o diamond-time.log /usr/bin/timeout -k 20 $TIMEOUT $DMCSPATH/new_dmcsc --hostname=localhost --port=5000 --root=0 --signature=$TESTPATH/client.qp --belief-state-size=20 --k1=1 --k2=1 --loop=1 > diamond.log 2> diamond-err.log
