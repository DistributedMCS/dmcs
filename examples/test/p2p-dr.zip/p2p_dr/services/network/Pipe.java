package network;

import java.net.*;
import java.io.*;

public class Pipe
{
  private Socket s;
  private String IPAddress;
  private int port;
  private ObjectInputStream ois;
  private ObjectOutputStream oos;

  public Pipe(String IPAddress, int port)
  throws Throwable
  {
    this.IPAddress = new String(IPAddress);
    this.s = new Socket(IPAddress, port);
    this.port = port;
    this.oos = new ObjectOutputStream(this.s.getOutputStream());
    this.ois = new ObjectInputStream(this.s.getInputStream());
  }

  public Pipe(Socket s)
  throws Throwable
  {
    this.IPAddress = new String((s.getRemoteSocketAddress()).toString());
    this.port = s.getPort();
    this.s = s;
    this.oos = new ObjectOutputStream(this.s.getOutputStream());
    this.ois = new ObjectInputStream(this.s.getInputStream());
  }

  public void writeToStream(Object o)
  throws Throwable
  {
    this.oos.writeObject(o);
    this.oos.flush();
  }

  public Object readFromStream()
  throws Throwable
  {
    return(this.ois.readObject());
  }

  public String getIPAddress()
  {
	String[] ar;

	ar = ((this.s.getInetAddress()).toString()).split("/");

    return(ar[1]);
  }
}
  
