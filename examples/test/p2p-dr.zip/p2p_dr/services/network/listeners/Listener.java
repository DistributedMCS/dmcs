/*
P2P_DR implementation in Java: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Evaluation: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Algorithm specification: Antonis Bikakis( bikakis@ics.forth.gr ) and Grigoris Antoniou ( antoniou@ics.forth.gr )
*/

package network.listeners;

import java.net.ServerSocket;
import java.net.Socket;
import java.io.IOException;

public abstract class Listener
extends ServerSocket
{
	protected int port;

	public Listener(int port)
	throws IOException
	{
		super(port);
		this.port = port;
	}

	public int getPort()
	{
		return(this.port);
	}

	public void waitForConnections()
	{
		Socket socket;

		try
		{ 
			while(true)
			{
				socket = this.accept();
				this.manageConnection(socket);
			}
		}
		catch(Throwable t)
		{
			System.out.println("Error in creating socket in module Listener");
			t.printStackTrace();
		}
	}

	public void dischard()
	{
		try
		{ this.close(); }
		catch(Throwable t)
		{
			System.out.println("Error in destroying socket in module Listener");
			t.printStackTrace();
		}
	}

	public abstract void manageConnection(Socket socket) throws Throwable;
}
