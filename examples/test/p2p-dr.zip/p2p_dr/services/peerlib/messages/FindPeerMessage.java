package peerlib.messages;

public class FindPeerMessage
implements Message
{
  private String peerName;
  private String peerGroupName;

  public FindPeerMessage(String peerName, String peerGroupName)
  {
    this.peerName = new String(peerName);
    this.peerGroupName = new String(peerGroupName);
  }

  public String getPeerName()
  {
    return(new String(this.peerName));
  }

  public String getPeerGroupName()
  {
    return(new String(this.peerGroupName));
  }
}
