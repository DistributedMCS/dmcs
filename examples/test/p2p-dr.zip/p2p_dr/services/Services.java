/*
P2P_DR implementation in Java: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Evaluation: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Algorithm specification: Antonis Bikakis( bikakis@ics.forth.gr ) and Grigoris Antoniou ( antoniou@ics.forth.gr )
*/

import network.*;
import network.listeners.*;
import peerlib.messages.*;
import java.util.*;
import java.io.*;
import java.net.*;

public class Services
extends Listener{
	private Hashtable groups;
	private Hashtable a;
        private static final int serverWaitPort = 1030;

	public Services(int port)
	throws IOException
	{
		super(port);
		a = new Hashtable();
		groups = new Hashtable();	}

	public void manageEnrollGroupMessage(Message m, Pipe pipe)
	throws Throwable
	{
		Hashtable h;

		h = (Hashtable)groups.get(((EnrollGroupMessage)m).getPeerGroupName());

		if(h == null)
		{
			h = new Hashtable();
			h.put(((EnrollGroupMessage)m).getPeerName(), pipe.getIPAddress());
			groups.put(((EnrollGroupMessage)m).getPeerGroupName(), h);
			a.put( ((EnrollGroupMessage)m).getPeerName(), new Integer(((EnrollGroupMessage)m).getPort()));
		}
		else
		{
			h.put(((EnrollGroupMessage)m).getPeerName(), pipe.getIPAddress());
			groups.put(((EnrollGroupMessage)m).getPeerGroupName(), h);
			a.put(((EnrollGroupMessage)m).getPeerName(), new Integer(((EnrollGroupMessage)m).getPort()));
		}

		System.out.println("   New peer: " + pipe.getIPAddress() + " " + ((EnrollGroupMessage)m).getPeerName()
						   + " " + ((EnrollGroupMessage)m).getPeerGroupName());
	}

	public void manageFindPeerMessage(Message m, Pipe pipe)
	throws Throwable
	{
		Hashtable h;
		String IPAddress;
		int port;
		
		h = (Hashtable)groups.get(((FindPeerMessage)m).getPeerGroupName());

		if(h == null)
			pipe.writeToStream(new ErrorMessage("GROUP NOT FOUND"));
		else
		{
			IPAddress = (String)h.get(((FindPeerMessage)m).getPeerName());
			port  = ((Integer)a.get(((FindPeerMessage)m).getPeerName())).intValue();
			if(IPAddress != null)
				pipe.writeToStream(new FindPeerResponse(IPAddress, port));	
			else
				pipe.writeToStream(new ErrorMessage("PEER NOT FOUND"));
		}

	}

	public void manageConnection(Socket socket)
	throws Throwable
	{
		Pipe pipe;
		Message m;

		pipe = new Pipe(socket);
		m = (Message) pipe.readFromStream();
		
		if(m instanceof EnrollGroupMessage)
			manageEnrollGroupMessage(m, pipe);
		else
			manageFindPeerMessage(m, pipe);
	}

	public static void main(String[] args)
	{
		Services s;

		try
		{
			s = new Services(serverWaitPort);
			System.out.println("\n   Server up and running\n");
			s.waitForConnections();
		}
		catch(Throwable t)
		{
			System.out.println("Error in server");
			t.printStackTrace();
		}

		return;
	}
}
