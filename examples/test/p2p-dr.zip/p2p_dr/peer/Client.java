/*
P2P_DR implementation in Java: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Evaluation: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Algorithm specification: Antonis Bikakis( bikakis@ics.forth.gr ) and Grigoris Antoniou ( antoniou@ics.forth.gr )
*/

import peerlib.*;
import peerlib.messages.*;
import java.io.*;
import agencies.messages.*;
import logic.*;
import java.util.*;

public class Client
{
  private static final String groupName = "group";

  public static void main(String[] args)
  {
    AdHocNetworkManager adhoc;
    String query;
    Peer peer;
    FindPeerResponse m;
    QueryResponse queryResponse;
    String[] literalString;
    boolean sign;

    try
    {
	adhoc = new AdHocNetworkManager();
	adhoc.setNameServer(args[1]);
	m = adhoc.findPeer(args[0], groupName);

	System.out.println("\n Query Client - on and ready!");

	while(true)
	{
	  peer = new Peer("servant", m.getIPAddress(), m.getPort());

	  System.out.print("\n --? ");
	  query = retrieveInputString(System.in);

	  sign = getSign(query);
	  literalString = query.split("~");

	  peer.send(new Query(new Literal(((literalString.length>1) ? literalString[1]:literalString[0]), "local", sign), 
			      false, new LinkedList(), new LinkedList(), new LinkedList()));

	  queryResponse = (QueryResponse)peer.receive();

	  if(queryResponse.isBooleanAnswer())
		  System.out.println(" Servant responded: " + queryResponse.getReturnValue());
	  else
		  printTriadicAnswer(((MyTriadic)queryResponse.getReturnAnswer()).getAnswerType());

	  printReceivedSet(" Supporting set: ", queryResponse.getSupportingSet());
	  printReceivedSet(" Conflicting set: ", queryResponse.getConflictingSet());
	}
    }
    catch(Throwable t)
    {
      t.printStackTrace();
    }
  }

  public static void printTriadicAnswer(byte answer)
  {
	switch(answer)
	{
	  case 1   : System.out.println(" positive strong"); break;
	  case 2   : System.out.println(" positive weak"); break;
	  case 3   : System.out.println(" no"); break;
	  default  : System.exit(1); break;
	}
  }

  public static void printReceivedSet(String msg, Collection c)
  {
	if(c != null)
	{
	  Iterator iter;
	  Object o;

	  iter = c.iterator();
	  System.out.print(msg + "[ ");

	  while(iter.hasNext())
	  {
		 o = iter.next();
		 System.out.print(o.toString() + ( iter.hasNext() == true ? " , " : " " ) );
	  }

	  System.out.println("]");	  
	}
  }

  public synchronized static int retrieveInputNumber(InputStream is)
  {
    BufferedReader input = new BufferedReader(new InputStreamReader(is));
    String str = null;
    int n = 0;
		
    try { str = input.readLine(); }
    catch(IOException e)
    {
	System.out.println("\n\n\tError at input-exiting...");
	System.exit(1);
    }

    try { n = Integer.parseInt(str); }
    catch(NumberFormatException e)
    {
	System.out.println(" Unknown input");
	return(-1);
    }
		
    return(n);
  }

  public synchronized static String retrieveInputString(InputStream is)
  {
    BufferedReader input = new BufferedReader(new InputStreamReader(is));
    String str = null;		
    try { str = input.readLine(); }    catch(IOException e)
    {
	System.out.println("\n\n\tError at input-exiting...");
	System.exit(1);
    }

    return(str);
  }

  public static boolean getSign(String s)
  {
    if(!s.startsWith("~"))
     return(true);
    else
     return(false);
  }
}
