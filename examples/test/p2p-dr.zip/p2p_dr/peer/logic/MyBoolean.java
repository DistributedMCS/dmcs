/*
P2P_DR implementation in Java: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Evaluation: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Algorithm specification: Antonis Bikakis( bikakis@ics.forth.gr ) and Grigoris Antoniou ( antoniou@ics.forth.gr )
*/

package logic;

import java.io.*;

public class MyBoolean
implements Serializable, Answer
{
  private boolean b;

  public MyBoolean(boolean b)
  {
    this.b = b;
  }

  public boolean getMyBoolean()
  {
    return(this.b);
  }

  public void setMyBoolean(boolean b)
  {
    this.b = b;
  }

}
	
