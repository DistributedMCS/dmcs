/*
P2P_DR implementation in Java: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Evaluation: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Algorithm specification: Antonis Bikakis( bikakis@ics.forth.gr ) and Grigoris Antoniou ( antoniou@ics.forth.gr )
*/

package logic;

import java.util.*;

public class Rule
{
  private Literal head;
  private Collection body;  	// of Literals (temporarily a LinkedList)
  private String name;
  private String mappingType;


  /* By calling this method, an always true local rule
     is created - body will be "null" */

  public Rule(Literal head, String name, String mappingType)
  {
    this.head = head;
    this.name = new String(name);
    this.mappingType = new String(mappingType);
    this.body = null;
  }

  public Rule(Literal head, String name, String mappingType, Collection literals)
  {
    this.head = head;
    this.name = new String(name);
    this.mappingType = new String(mappingType);
    this.body = new LinkedList(literals);
  }

  public Iterator getBody()
  {
    return( (this.body == null) ? null : this.body.iterator() );
  }

  public String getRuleName()
  {
    return(new String(this.name));
  }

  public String getHeadName()
  {
    return(new String(this.head.getName()));
  }

  public Literal getHead()
  {
    return(this.head);
  }
  
  public String getMappingType()
  {
    return(new String(this.mappingType));
  }

}
