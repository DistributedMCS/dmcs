/*
P2P_DR implementation in Java: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Evaluation: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Algorithm specification: Antonis Bikakis( bikakis@ics.forth.gr ) and Grigoris Antoniou ( antoniou@ics.forth.gr )
*/

package logic;

import java.io.*;

public class Literal
implements Serializable
{
  private String name;
  private String location; 
  private boolean sign;

  public Literal(String name, String location, boolean sign)
  {
    this.name = new String(name);
    this.sign = sign;
    this.location = new String(location);
  }

  public String getName()
  {
    return(new String(this.name));
  }

  public String getLocation()
  {
    return(new String(this.location));
  }

  public String getSignWithName()
  {
	if(this.sign)
	  return(new String(this.name));
	else
      return(new String("~"+this.name));
  }

  public boolean getSign()
  {
    return(this.sign);
  }

  public void reverseSign()
  {
    this.sign = !(this.sign);
  }

  public String toString()
  {
	return(new String(name));
  }
}
	
