package agencies;

import logic.*;
import knowledge.*;
import java.util.*;
import java.io.*;

public class FileServant
implements Servant
{
  private String filename;
  private KnowledgeBase kb;

  public FileServant(String filename)
  {
    this.filename = new String(filename);
  }

  public void serve()
  {
    BufferedReader br;
    String processedLine ,literal;
    String[] lineParticles, ruleParts, body, literalString, tmpArray, tmpArray2;
    LinkedList bodyList;
    int i;
    String rule;
    boolean sign = false;
	char setName[] = new char[1];

    try
    {
	  kb = KnowledgeBase.getInstance();	  
	  br = new BufferedReader(new InputStreamReader(new FileInputStream(this.filename)));

	  while(br.ready())
	  {
		processedLine = br.readLine();

		if(processedLine.length()>=5)
		{
		if(processedLine.charAt(0)!='#')
		{
		  lineParticles = processedLine.split(":");
		  rule = lineParticles[1].trim();		  
		  ruleParts = rule.split("->");
		  ruleParts[0] = ruleParts[0].trim();
		  ruleParts[1] = ruleParts[1].trim();

		  //System.out.println(ruleParts[0].length());
		  if(ruleParts[0].length()==0)
		  {
			literalString = null;
			sign = getSign(ruleParts[1]);
//			System.out.println(" * " + ruleParts[1] + " " + sign);
			literalString = ruleParts[1].split("~");
			literal = ((literalString.length>1) ? literalString[1]:literalString[0]);
			tmpArray2 = literal.split("_");

			 // System.out.println(" + " + literal + " " + sign);


			if(tmpArray2[1].equals("local")){
				kb.addLocalLiteral(new Literal(tmpArray2[0], tmpArray2[1], sign));
				//System.out.println("p " + tmpArray2[0]);
			}

			setName[0] = lineParticles[0].charAt(0);
			kb.addRule(new String(setName), new Rule(new Literal(tmpArray2[0], tmpArray2[1], sign), lineParticles[0], lineParticles[0]));

//			System.out.println(" -p  setName=" + setName[0] + " " + tmpArray2[0] +" "+ tmpArray2[1] + " "+sign);
		  }
		  else
		  {
			body = ruleParts[0].split(",");
			bodyList = new LinkedList();

			for(i=0;i<body.length;i++)
			{
			  body[i] = body[i].trim();
			  sign = getSign(body[i]);
			  literalString = body[i].split("~");
			  literal = ((literalString.length>1) ? literalString[1]:literalString[0]);
			  tmpArray = literal.split("_");
			  bodyList.add(new Literal(tmpArray[0], tmpArray[1], sign));

//			  System.out.println(" + " + literal + " " + sign);
			  
			  if(tmpArray[1].equals("local")) {
				kb.addLocalLiteral(new Literal(tmpArray[0], tmpArray[1], sign));
				//System.out.println(tmpArray[0]);
			  }

//			System.out.println(" --" + tmpArray[0] +" "+ tmpArray[1] + " "+sign);
			}

			literalString = null;
			ruleParts[0] = ruleParts[0].trim();
			ruleParts[1] = ruleParts[1].trim();

			sign = getSign(ruleParts[1]);
			//System.out.println(" _ " + ruleParts[1] + " " + sign);
			literalString = ruleParts[1].split("~");
			literal = ((literalString.length>1) ? literalString[1]:literalString[0]);
			tmpArray2 = literal.split("_");

//			System.out.println(" + " + literal + " " + sign);


			if(tmpArray2[1].equals("local")){
				kb.addLocalLiteral(new Literal(tmpArray2[0], tmpArray2[1], sign));
				//System.out.println(tmpArray2[0]);
			}

			//System.out.println(" __" + tmpArray2[0] +" "+ tmpArray2[1] + " "+sign);
		    //System.out.println(sign + " " + ((literalString.length>1) ? literalString[1]:literalString[0]));
			
			setName[0] = lineParticles[0].charAt(0);

			kb.addRule(new String(setName), new Rule(new Literal(tmpArray2[0], tmpArray2[1], sign), lineParticles[0],
				       lineParticles[0], bodyList));

//			System.out.println(" --  setName=" + setName[0] + " " + tmpArray2[0] +" "+ tmpArray2[1] + " "+sign);

		  }
		}
		}
	  }

	  //kb.print();
   }
   catch(Throwable t)
   {
     t.printStackTrace();
   }
}

  public boolean getSign(String s)
  {
    if(!s.startsWith("~"))
     return(true);
    else
     return(false);
  }

}
