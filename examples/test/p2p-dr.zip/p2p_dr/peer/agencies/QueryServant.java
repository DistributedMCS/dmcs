
/*
P2P_DR implementation in Java: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Evaluation: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Algorithm specification: Antonis Bikakis( bikakis@ics.forth.gr ) and Grigoris Antoniou ( antoniou@ics.forth.gr )
*/

package agencies;

import peerlib.*;
import peerlib.messages.*;
import logic.*;
import knowledge.*;
import java.util.*;
import agencies.messages.*;

public abstract class QueryServant
implements Servant
{
  protected boolean flag = false;
  protected Peer incomingPeer;
  protected IncQueriesCache incQueriesCache;
  protected OutQueriesCache outQueriesCache;
  protected String servicesAddress;
  protected String groupName;
  protected static int outOfProportion = -2;
  protected AdHocNetworkManager adhoc;
  protected Peer outcomingPeer;
  protected Literal literal, queryLiteral;
  protected MyBoolean localAnswer;
  protected AnswerSet cachedAnswer;
  protected LinkedList currLocalHistory, supportingRules, inheritedHistory, bequeathHistory;
  protected LinkedList suppForLiteral, conflForLiteral;
  protected Collection inheritedSupportingRules, inheritedConflictingRules, rulesCollection;
  protected Query query;
  protected KnowledgeBase kb;
  protected Rule rule;
  protected Iterator rules, body;
  protected FindPeerResponse findPeerMessage;
  protected QueryResponse queryResponse;


  // As it is passed from peerlib.handlers.ResponseHandler class

  public void setParameters(Peer p, String servicesAddress, String groupName)
  {
    this.incomingPeer = p;
	this.servicesAddress = new String(servicesAddress);
	this.groupName = new String(groupName);
  }

  public abstract void serve();

  public void run()
  {
    serve();
  }

  public abstract void handleConflictingSet() throws Throwable;

  public abstract void handleSupportingSet() throws Throwable;

  public void init()
  throws Throwable
  {
    currLocalHistory = new LinkedList();
	incQueriesCache = IncQueriesCache.getInstance();
	outQueriesCache = OutQueriesCache.getInstance();

    adhoc = AdHocNetworkManager.getInstance(this.servicesAddress);
    kb = KnowledgeBase.getInstance();
  }

  public void resolveConflicts()
  throws Throwable
  {
	  System.out.print("\tSolving the conflicts: ");

	  if(isStronger(inheritedSupportingRules, inheritedConflictingRules, kb.getTrustOrder())==inheritedSupportingRules)
      {
	    System.out.println(" the supporting set wins!\n");
		incQueriesCache.rememberLiteral(queryLiteral, new MyBoolean(true), inheritedSupportingRules );
		incomingPeer.send(new QueryResponse(new MyBoolean(true), inheritedSupportingRules, null));
		return;
      }
	  else
      {
	    System.out.println(" the conflicting set wins!\n");
		incQueriesCache.rememberLiteral(queryLiteral, new MyBoolean(false), inheritedConflictingRules);
		//System.out.println(inheritedConflictingRules);
		incomingPeer.send(new QueryResponse(new MyBoolean(false), null, inheritedConflictingRules));
		return;
      }
  }

  public Collection uniteSets(Collection setA, Collection setB)
  {
    Iterator iterA, iterB;
	LinkedList c;

	c = new LinkedList();

	if(setA==null)
		return(setB);
	else
	    iterA = setA.iterator();		

	if(setB==null)
		return(setA);
	else
		iterB = setB.iterator();
	
    while(iterA.hasNext())
      c.add(iterA.next());

    while(iterB.hasNext())
      c.add(iterB.next());
	
	//	System.out.println("gmt gmt gmt");
	return(c);
	
  }

  public Collection isStronger(Collection setA, Collection setB, ArrayList trust)
  {
    Literal rA, rB;

    rA = findWeakest(setA, trust);
    rB = findWeakest(setB, trust);

//	System.out.println(rA);
//	System.out.println(rB);

    if(isReliable(rA, rB, trust)){
//	System.out.println(setA);
		return(setA);
		}
	else if(isReliable(rB, rA, trust)){
//	System.out.println(setB);
		return(setB);
	}
	else
		return(null);
  }

  public boolean isReliable(Literal rA, Literal rB, ArrayList trust)
  {
	int seqNumA, seqNumB;

	if(rA==null)
		seqNumA = outOfProportion;
	else
	for(seqNumA=0; seqNumA<trust.size(); seqNumA++)
		if(rA.getLocation().equals((String)trust.get(seqNumA))) break;

	if(rB==null)
		seqNumB = outOfProportion;
	else
	for(seqNumB=0; seqNumB<trust.size(); seqNumB++)
		if(rB.getLocation().equals((String)trust.get(seqNumB))) break;

	//System.out.println("seqNUmA=" + seqNumA + " seqB=" + seqNumB);
	return(seqNumA < seqNumB ? true :  false);
  }

  public Literal findWeakest(Collection setA, ArrayList trust)
  {
    Object[] ruleList;
    Literal rule;
    int i, j;

    ruleList = setA.toArray();

    for(i=trust.size()-1;i>=0;i--)
    {
		for(j=0;j<ruleList.length;j++)
		{
			rule = (Literal) ruleList[j];
			if( (rule.getLocation()).equals((String)trust.get(i)) )
				return(rule);
		}
	}

    return(null);
  }	

  public void local_alg(Literal queryLiteral, Collection localHist, MyBoolean localAnswer)
  throws Throwable
  {
    Iterator body, rules, valuesIterator;
    Literal literal;
    Collection rulesCollection, literalValues;
    Rule rule;
    MyBoolean literalLocalAnswer;
    KnowledgeBase kb = KnowledgeBase.getInstance();

    try 
    {
	  literalValues = new LinkedList();
	  rulesCollection = (Collection) kb.getRulesByHeadLiteral("L", queryLiteral);
    }
    catch(UnknownRuleException ure)
    {
	  localAnswer.setMyBoolean(false);
	  return;
    } // closed world assumption

	rules = rulesCollection.iterator();
    
    while(rules.hasNext())
    {
	  rule = (Rule) rules.next();
	  body = rule.getBody();
    
	  if(body == null)
	  {
	  	localAnswer.setMyBoolean(true);
	  	return;	// termination condition
	  }

	  while(body.hasNext())
	  {
	    literal = (Literal) body.next();

	    if(localHist.contains(literal.getName()))
		break;
	    else
	    {
		 localHist.add(new String(literal.getName()));
		 literalLocalAnswer = new MyBoolean(false);
		 local_alg(literal, localHist, literalLocalAnswer);
		 literalValues.add(literalLocalAnswer);
	    }
	  }

	  valuesIterator = literalValues.iterator();

	  while(valuesIterator.hasNext())
	  if( ((MyBoolean)valuesIterator.next()).getMyBoolean()==false)
	  {
	     localAnswer.setMyBoolean(false);
	     return;
	  }

	  localAnswer.setMyBoolean(true);
	  return;
    }
  }

}
