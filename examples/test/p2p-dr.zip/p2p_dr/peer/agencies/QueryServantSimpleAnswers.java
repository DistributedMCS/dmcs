
/*
P2P_DR implementation in Java: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Evaluation: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Algorithm specification: Antonis Bikakis( bikakis@ics.forth.gr ) and Grigoris Antoniou ( antoniou@ics.forth.gr )
*/
package agencies;

import peerlib.*;
import peerlib.messages.*;
import logic.*;
import knowledge.*;
import java.util.*;
import agencies.messages.*;

public class QueryServantSimpleAnswers
extends QueryServant
implements Runnable
{
  public void serve()
  {

	long startTime, endTime;

	try
    {
	  init();

      query = (Query)incomingPeer.receive();

	  startTime = (new Date()).getTime();

      queryLiteral = query.getLiteral();
      inheritedHistory = (LinkedList)query.getHistory();
      inheritedSupportingRules  = query.getSupportingMappings();
      inheritedConflictingRules = query.getConflictingMappings();
	  
	  System.out.println("\n\n |||||| New query session ||||||\n");
	  System.out.print("\tLocal reasoning for: " + queryLiteral.getSignWithName());

	  if((cachedAnswer=incQueriesCache.getAnswerForLiteral(queryLiteral))!=null)
	  {
		System.out.println(" is already cached: " + ((MyBoolean)cachedAnswer.getAnswer()).getMyBoolean() );
        if(queryLiteral.getSign()==true)
			incomingPeer.send(new QueryResponse(cachedAnswer.getAnswer(), cachedAnswer.getSet(), null));
		else
			incomingPeer.send(new QueryResponse(cachedAnswer.getAnswer(), null, cachedAnswer.getSet()));

		return;
	  }

	  if(kb.isRuleInside("L", queryLiteral))
      {
		localAnswer = new MyBoolean(false);
		currLocalHistory.add(queryLiteral);
        local_alg(queryLiteral, currLocalHistory, localAnswer);

		if(localAnswer.getMyBoolean())
	    {
			System.out.println("  Answer: " + localAnswer.getMyBoolean());
			incQueriesCache.rememberLiteral(queryLiteral, localAnswer, null);
			incomingPeer.send(new QueryResponse(localAnswer, null, null));
			return;
		}
      }

      queryLiteral.reverseSign();

      if(kb.isRuleInside("L", queryLiteral))
      {
        localAnswer = new MyBoolean(false);
        currLocalHistory.clear();
        currLocalHistory.add(queryLiteral);
        local_alg(queryLiteral, currLocalHistory, localAnswer);

		if(localAnswer.getMyBoolean())
		{
			localAnswer.setMyBoolean(false);
	        queryLiteral.reverseSign();
			incQueriesCache.rememberLiteral(queryLiteral, localAnswer, null);
			queryLiteral.reverseSign();
			incomingPeer.send(new QueryResponse(localAnswer, null, null));
			return;
		}
      }

      queryLiteral.reverseSign();


	  ////////////////////////////////////////////////////////////////////////
      ////////////// distributed reasoning for supporting rules //////////////

	  rulesCollection = (Collection) kb.getSupportingRulesByHeadLiteral(queryLiteral);
      rules = rulesCollection.iterator();

	  System.out.println("\n\n\tReasoning for support of literal: " + queryLiteral.getSignWithName());
      while(rules.hasNext())
      {
		flag = false;
		supportingRules = new LinkedList();
	
		rule = (Rule) rules.next();
		body = rule.getBody();
    
		bequeathHistory = new LinkedList(inheritedHistory);

		while(body.hasNext())
		{
			literal = (Literal) body.next();

			if(inheritedHistory.contains(literal.getSignWithName()))
			{
				flag = true;
				break;
			}
			else
			{
				uniteSets(bequeathHistory, inheritedHistory);
				bequeathHistory.add(literal.getSignWithName());

			    if((cachedAnswer=outQueriesCache.getAnswerForLiteral(literal))!=null)
			    {
				 System.out.println("\n\n\tRequest : " + literal.getSignWithName() + " wont go to network, is already cached: " + ((MyBoolean)cachedAnswer.getAnswer()).getMyBoolean() );
				 queryResponse  = new QueryResponse(cachedAnswer.getAnswer(), cachedAnswer.getSet(), null);
//				 incomingPeer.send(new QueryResponse(cachedAnswer.getAnswer(), cachedAnswer.getSet(), null));
//				 return;
			    }
				else
				{

				findPeerMessage = adhoc.findPeer(literal.getLocation(), this.groupName);
				outcomingPeer = new Peer(literal.getLocation(), findPeerMessage.getIPAddress(), findPeerMessage.getPort());

			    suppForLiteral  = new LinkedList();
				conflForLiteral = new LinkedList();
				System.out.println("\tRequesting literal: " + literal.getSignWithName() + "  from: " + literal.getLocation() + "\n");
				outcomingPeer.send(new Query(literal, false, suppForLiteral, conflForLiteral, bequeathHistory));
				queryResponse  = (QueryResponse)outcomingPeer.receive();

				}

				if(queryResponse.getReturnValue()==false)
				{
					flag = true;
					break;
				}
				else if(queryResponse.getReturnValue()==true && (kb.isLocalLiteralInside(literal)==false))
					supportingRules.add(literal);
				else {
					supportingRules = (LinkedList) uniteSets(supportingRules, queryResponse.getSupportingSet());
				}

				outQueriesCache.rememberLiteral(literal, new MyBoolean(queryResponse.getReturnValue()), supportingRules);
			}
		}

		if(flag==true)
			continue;
		else
			handleSupportingSet();
	  }  

	  if(inheritedSupportingRules.size()==0)
      {
		incQueriesCache.rememberLiteral(queryLiteral, new MyBoolean(false), null);
		incomingPeer.send(new QueryResponse(new MyBoolean(false), null, null));
		return;
      }

	  
	  /////////////////////////////////////////////////////////////////////////
      ////////////// distributed reasoning for conflicting rules //////////////

	  rulesCollection = (Collection) kb.getConflictingRulesByHeadLiteral(queryLiteral);
      rules = rulesCollection.iterator();
	  System.out.println("\tReasoning for conflicts for literal: " + queryLiteral.getSignWithName());

      while(rules.hasNext())
      {
		flag = false;
		supportingRules = new LinkedList();
	
		rule = (Rule) rules.next();
		body = rule.getBody();
    
		bequeathHistory = new LinkedList(inheritedHistory);

		while(body.hasNext())
		{
			literal = (Literal) body.next();

			if(inheritedHistory.contains(literal.getSignWithName()))
			{
				flag = true;
				break;
			}
			else
			{
				uniteSets(bequeathHistory, inheritedHistory);
				bequeathHistory.add(literal.getSignWithName());

			    if((cachedAnswer=outQueriesCache.getAnswerForLiteral(literal))!=null)
			    {
				 System.out.println("\n\n\tRequest : " + literal.getSignWithName() + " wont go to network, is already cached: " + ((MyBoolean)cachedAnswer.getAnswer()).getMyBoolean() );
				 queryResponse  = new QueryResponse(cachedAnswer.getAnswer(), cachedAnswer.getSet(), null);
//				 incomingPeer.send(new QueryResponse(cachedAnswer.getAnswer(), cachedAnswer.getSet(), null));
//				 return;
			    }
				else
				{

				findPeerMessage = adhoc.findPeer(literal.getLocation(), this.groupName);
				outcomingPeer = new Peer(literal.getLocation(), findPeerMessage.getIPAddress(), findPeerMessage.getPort());

			    suppForLiteral  = new LinkedList();
				conflForLiteral = new LinkedList();
				System.out.println("\tRequesting literal: " + literal.getSignWithName() + "  from: " + literal.getLocation() + "\n");
			    outcomingPeer.send(new Query(literal, false, suppForLiteral, conflForLiteral, bequeathHistory));
    		    queryResponse  = (QueryResponse)outcomingPeer.receive();

				}

				if(queryResponse.getReturnValue()==false)
				{
					flag = true;
					break;
				}
				else if(queryResponse.getReturnValue()==true && (kb.isLocalLiteralInside(literal)==false))
					supportingRules.add(literal);
				else
					supportingRules = (LinkedList) uniteSets(supportingRules, queryResponse.getSupportingSet());

				outQueriesCache.rememberLiteral(literal, new MyBoolean(queryResponse.getReturnValue()), supportingRules);
	
			}
		}
		if(flag==true)
			continue;
		else
			handleConflictingSet();
	  }  

	  endTime = (new Date()).getTime();

	  System.out.println("\n   Time taken: " + (endTime - startTime));

      if(inheritedConflictingRules.size()==0)
      {
		incQueriesCache.rememberLiteral(queryLiteral, new MyBoolean(true), inheritedSupportingRules);
		incomingPeer.send(new QueryResponse(new MyBoolean(true), inheritedSupportingRules, null));
		return;
      }

	  resolveConflicts();
	}
    catch(Throwable t)
    {
      t.printStackTrace();
    }
  }

  public void handleConflictingSet()
  throws Throwable
  {
	if(inheritedConflictingRules.size()==0 || isStronger(supportingRules, inheritedConflictingRules, kb.getTrustOrder())==supportingRules)
      inheritedConflictingRules = supportingRules;
  }

  public void handleSupportingSet()
  throws Throwable
  {
	if(inheritedSupportingRules.size()==0 || isStronger(supportingRules, inheritedSupportingRules, kb.getTrustOrder())==supportingRules)
      inheritedSupportingRules = supportingRules;
  }

 public void run()
 {
   serve();
 }
}
