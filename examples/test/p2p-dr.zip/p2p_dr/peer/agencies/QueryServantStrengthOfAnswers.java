/*
P2P_DR implementation in Java: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Evaluation: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Algorithm specification: Antonis Bikakis( bikakis@ics.forth.gr ) and Grigoris Antoniou ( antoniou@ics.forth.gr )
*/

package agencies;

import peerlib.*;
import peerlib.messages.*;
import logic.*;
import knowledge.*;
import java.util.*;
import agencies.messages.*;

public class QueryServantStrengthOfAnswers
extends QueryServant
implements Runnable
{
  public void serve()
  {
	MyTriadic answer;
	long startTime, endTime;
	
	try
    {
	  init();

  	  startTime = (new Date()).getTime();

      query = (Query)incomingPeer.receive();
      queryLiteral = query.getLiteral();
      inheritedHistory = (LinkedList)query.getHistory();
      inheritedSupportingRules  = query.getSupportingMappings();
      inheritedConflictingRules = query.getConflictingMappings();
	  
	  System.out.println("\n\n |||||| New query session ||||||\n");

	  System.out.print("\tLocal reasoning for: " + queryLiteral.getName());

	  if(kb.isRuleInside("L", queryLiteral))
      {
		localAnswer = new MyBoolean(false);
		currLocalHistory.add(queryLiteral);
        local_alg(queryLiteral, currLocalHistory, localAnswer);

		if(localAnswer.getMyBoolean())
		  {
			System.out.println("  Answer: " + localAnswer.getMyBoolean());
			incQueriesCache.rememberLiteral(queryLiteral, localAnswer, null);
			incomingPeer.send(new QueryResponse(new MyTriadic(queryLiteral, MyTriadic.StrictAnswer), null, null));
			return;
		}
      }

      queryLiteral.reverseSign();

      if(kb.isRuleInside("L", queryLiteral))
      {
        localAnswer = new MyBoolean(false);
        currLocalHistory.clear();
        currLocalHistory.add(queryLiteral);
        local_alg(queryLiteral, currLocalHistory, localAnswer);

		if(localAnswer.getMyBoolean())
		{
			localAnswer.setMyBoolean(false);
			System.out.println("  Answer: " + localAnswer.getMyBoolean());
	        queryLiteral.reverseSign();
			incQueriesCache.rememberLiteral(queryLiteral, localAnswer, null);
			queryLiteral.reverseSign();
			incomingPeer.send(new QueryResponse(new MyTriadic(queryLiteral, MyTriadic.NoAnswer), null, null));
			return;
		}
      }

      queryLiteral.reverseSign();

	  ////////////////////////////////////////////////////////////////////////
      ////////////// distributed reasoning for supporting rules //////////////

	  rulesCollection = (Collection) kb.getSupportingRulesByHeadLiteral(queryLiteral);
      rules = rulesCollection.iterator();

	  System.out.println("\n\n\tReasoning for support of literal: " + queryLiteral.getSignWithName());
      while(rules.hasNext())
      {
		flag = false;
		supportingRules = new LinkedList();
	
		rule = (Rule) rules.next();
		body = rule.getBody();
    
		bequeathHistory = new LinkedList(inheritedHistory);

		while(body.hasNext())
		{
			literal = (Literal) body.next();

			if(inheritedHistory.contains(literal.getSignWithName()))
			{	
				flag = true;
				break;
			}
			else
			{
				uniteSets(bequeathHistory, inheritedHistory);
				bequeathHistory.add(literal.getSignWithName());
			    if((cachedAnswer=outQueriesCache.getAnswerForLiteral(literal))!=null)
			    {
				 System.out.println("\n\n\tRequest : " + literal.getSignWithName() + " wont go to network, is already cached: ");
				 queryResponse  = new QueryResponse(cachedAnswer.getAnswer(), cachedAnswer.getSet(), null);
//				 incomingPeer.send(new QueryResponse(cachedAnswer.getAnswer(), cachedAnswer.getSet(), null));
//				 return;
			    }
				else
				{


				findPeerMessage = adhoc.findPeer(literal.getLocation(), this.groupName);
				outcomingPeer = new Peer(literal.getLocation(), findPeerMessage.getIPAddress(), findPeerMessage.getPort());

			    suppForLiteral  = new LinkedList();
				conflForLiteral = new LinkedList();
				System.out.println("\tRequesting literal: " + literal.getSignWithName() + "  from: " + literal.getLocation() + "\n");
				outcomingPeer.send(new Query(literal, false, suppForLiteral, conflForLiteral, bequeathHistory));
    		    queryResponse  = (QueryResponse)outcomingPeer.receive();

				}

				answer = (MyTriadic) queryResponse.getReturnAnswer();

				if(answer.getAnswerType()==MyTriadic.NoAnswer)
				{	
					flag = true;
					break;
				}
				else if(answer.getAnswerType()!=MyTriadic.NoAnswer && (kb.isLocalLiteralInside(literal)==false))
					supportingRules.add(answer);
				else
					supportingRules = (LinkedList) uniteSets(supportingRules, suppForLiteral);

				outQueriesCache.rememberLiteral(literal, queryResponse.getReturnAnswer(), supportingRules);	
			}
		}
		if(flag==true)
			continue;
		else
			handleSupportingSet();
	  }  

      if(inheritedSupportingRules.size()==0)
      {
		incQueriesCache.rememberLiteral(queryLiteral, new MyTriadic(queryLiteral, MyTriadic.NoAnswer), null);
		incomingPeer.send(new QueryResponse(new MyTriadic(queryLiteral, MyTriadic.NoAnswer), null, null));
		return;
      }

	  /////////////////////////////////////////////////////////////////////////
      ////////////// distributed reasoning for conflicting rules //////////////

	  rulesCollection = (Collection) kb.getConflictingRulesByHeadLiteral(queryLiteral);
      rules = rulesCollection.iterator();
	  System.out.println("\tReasoning for conflicts for literal: " + queryLiteral.getSignWithName());

      while(rules.hasNext())
      {
		flag = false;
		supportingRules = new LinkedList();
	
		rule = (Rule) rules.next();
		body = rule.getBody();
    
		bequeathHistory = new LinkedList(inheritedHistory);

		while(body.hasNext())
		{
			literal = (Literal) body.next();

			if(inheritedHistory.contains(literal.getSignWithName()))
			{	
				flag = true;
				break;
			}
			else
			{
				uniteSets(bequeathHistory, inheritedHistory);
				bequeathHistory.add(literal.getSignWithName());

			    if((cachedAnswer=outQueriesCache.getAnswerForLiteral(literal))!=null)
			    {
				 System.out.println("\n\n\tRequest : " + literal.getSignWithName() + " wont go to network, is already cached: " );
				 queryResponse  = new QueryResponse(cachedAnswer.getAnswer(), cachedAnswer.getSet(), null);
//				 incomingPeer.send(new QueryResponse(cachedAnswer.getAnswer(), cachedAnswer.getSet(), null));
//				 return;
			    }
				else
				{

				findPeerMessage = adhoc.findPeer(literal.getLocation(), this.groupName);
				outcomingPeer = new Peer(literal.getLocation(), findPeerMessage.getIPAddress(), findPeerMessage.getPort());

			    suppForLiteral  = new LinkedList();
				conflForLiteral = new LinkedList();
				System.out.println("\tRequesting literal: " + literal.getSignWithName() + "  from: " + literal.getLocation() + "\n");
			    outcomingPeer.send(new Query(literal, false, suppForLiteral, conflForLiteral, bequeathHistory));
    		    queryResponse  = (QueryResponse)outcomingPeer.receive();

				}

				answer = (MyTriadic) queryResponse.getReturnAnswer();

				if(answer.getAnswerType()==MyTriadic.NoAnswer)
				{	
					flag = true;
					break;
				}
				else if(answer.getAnswerType()!=MyTriadic.NoAnswer && (kb.isLocalLiteralInside(literal)==false))
					supportingRules.add(answer);
				else
					supportingRules = (LinkedList) uniteSets(supportingRules, suppForLiteral);

				outQueriesCache.rememberLiteral(literal, queryResponse.getReturnAnswer(), supportingRules);
			}
		}

		if(flag==true)
			continue;
		else
			handleConflictingSet();
	  }  

      if(inheritedConflictingRules.size()==0)
      {
		incQueriesCache.rememberLiteral(queryLiteral, new MyTriadic(queryLiteral, MyTriadic.WeakAnswer), null);
        incomingPeer.send(new QueryResponse(new MyTriadic(queryLiteral, MyTriadic.WeakAnswer), inheritedSupportingRules, null));
		return;
      }

	  endTime = (new Date()).getTime();

	  System.out.println("\n   Time taken: " + (endTime - startTime));

	  resolveConflicts();
	}
    catch(Throwable t)
    {
      t.printStackTrace();
    }
  }

  public void handleConflictingSet()
  throws Throwable
  {
	if(inheritedConflictingRules.size()==0 || this.isStronger(supportingRules, inheritedConflictingRules, kb.getTrustOrder())==supportingRules)
      inheritedConflictingRules = supportingRules;
  }

  public void handleSupportingSet()
  throws Throwable
  {
	if(inheritedSupportingRules.size()==0 || this.isStronger(supportingRules, inheritedSupportingRules, kb.getTrustOrder())==supportingRules)
      inheritedSupportingRules = supportingRules;
  }

  public void resolveConflicts()
  throws Throwable
  {
	  System.out.print("\tSolving the conflicts: ");

	  System.out.println(inheritedSupportingRules);
	  System.out.println(inheritedConflictingRules);

	  if(this.isStronger(inheritedSupportingRules, inheritedConflictingRules, kb.getTrustOrder())==inheritedSupportingRules)
      {
	    System.out.println(" the supporting set wins!\n");
//		incQueriesCache.rememberLiteral(queryLiteral, new MyBoolean(true));
		incomingPeer.send(new QueryResponse(new MyTriadic(queryLiteral, MyTriadic.WeakAnswer), inheritedSupportingRules, null));
		return;
      }
	  else
      {
	    System.out.println(" the conflicting set wins!\n");
//		incQueriesCache.rememberLiteral(queryLiteral, new MyBoolean(false));
        incomingPeer.send(new QueryResponse(new MyTriadic(queryLiteral, MyTriadic.NoAnswer), null, inheritedConflictingRules));
		return;
      }
  }

  public Collection isStronger(Collection setA, Collection setB, ArrayList trust)
  {
    MyTriadic rA, rB;

    rA = this.weakest(setA, trust);
    rB = this.weakest(setB, trust);

//	System.out.println(rA);
//	System.out.println(rB);

	if(rA.getAnswerType()==MyTriadic.StrictAnswer && rB.getAnswerType()==MyTriadic.WeakAnswer)
		return(setA);

	if(rB.getAnswerType()==MyTriadic.StrictAnswer && rA.getAnswerType()==MyTriadic.WeakAnswer)
		return(setB);

	if(isReliable(rA, rB, trust)){
//	System.out.println(setA);
		return(setA);
		}
	else if(isReliable(rB, rA, trust)){
//	System.out.println(setB);
		return(setB);
	}
	else
		return(null); 
  }

  public boolean isReliable(MyTriadic rA, MyTriadic rB, ArrayList trust)
  {
	int seqNumA, seqNumB;

	if(rA==null)
		seqNumA = outOfProportion;
	else
	for(seqNumA=0; seqNumA<trust.size(); seqNumA++)
		if(rA.getLiteral().getLocation().equals((String)trust.get(seqNumA))) break;

	if(rB==null)
		seqNumB = outOfProportion;
	else
	for(seqNumB=0; seqNumB<trust.size(); seqNumB++)
		if(rB.getLiteral().getLocation().equals((String)trust.get(seqNumB))) break;

	//System.out.println("seqNUmA=" + seqNumA + " seqB=" + seqNumB);
	return(seqNumA < seqNumB ? true :  false);
  }

  public MyTriadic weakest(Collection set, ArrayList trust)
  {
	LinkedList c;

	c = (LinkedList) splitWeakest(set);

	if(c.size()==0)
		return(this.findDaWeakest(set, trust));
	else
		return(this.findDaWeakest(c, trust));
  }

  public Collection splitWeakest(Collection set)
  {
	Iterator iter;
	MyTriadic answer;

	LinkedList c = new LinkedList();

	iter = set.iterator();

	while(iter.hasNext())
	{
	  answer = (MyTriadic) iter.next();

	  if(answer.getAnswerType()==MyTriadic.WeakAnswer)
		  c.add(answer);
	}

	return(c);
  }

  public MyTriadic findDaWeakest(Collection setA, ArrayList trust)
  {
    Object[] ruleList;
    MyTriadic answer;
    int i, j;

    ruleList = setA.toArray();

    for(i=trust.size()-1;i>=0;i--)
    {
		for(j=0;j<ruleList.length;j++)
		{
			answer = (MyTriadic) ruleList[j];
			if(answer.getLiteral().getLocation().equals((String)trust.get(i)))
				return(answer);
		}
	}

    return(null);
  }	

 public void run()
 {
   serve();
 }
}
