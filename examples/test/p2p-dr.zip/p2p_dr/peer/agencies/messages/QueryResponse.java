package agencies.messages;

import peerlib.messages.*;
import logic.*;
import java.util.*;

public class QueryResponse
implements Message
{
  private Answer returnValue;
  private Collection mappingSet;
  private Collection supportingSet;
  private Collection conflictingSet;

  public QueryResponse(Answer b, Collection c, Collection d)
  {
    this.returnValue = b;
    this.supportingSet   = c;
    this.conflictingSet  = d;
  }

  public boolean isBooleanAnswer()
  {
	return(this.returnValue instanceof MyBoolean);
  }

  public boolean getReturnValue()
  {
    return(((MyBoolean)this.returnValue).getMyBoolean());
  }

  public Answer getReturnAnswer()
  {
    return(this.returnValue);
  }  
  
  public Collection getSupportingSet()
  {
    return(this.supportingSet);
  }

  public Collection getConflictingSet()
  {
    return(this.conflictingSet);
  }
}
