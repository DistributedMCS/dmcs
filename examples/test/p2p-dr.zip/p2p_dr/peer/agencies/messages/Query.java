package agencies.messages;

import peerlib.messages.*;
import logic.*;
import java.util.*;

public class Query
implements Message
{
  private Literal query;
  private Answer localAnswer;
  private Collection suppMappingsSet;
  private Collection conflMappingsSet;
  private Collection history;

  public Query(Literal query, boolean localAnswer, Collection ss, Collection cs, Collection history)
  {
    this.query = query;
    this.suppMappingsSet  = ss;
    this.conflMappingsSet = cs;
    this.localAnswer = new MyBoolean(localAnswer);
    this.history = history;
  }

  public Query(Literal query, Answer localAnswer, Collection ss, Collection cs, Collection history)
  {
    this.query = query;
    this.suppMappingsSet  = ss;
    this.conflMappingsSet = cs;
    this.localAnswer = localAnswer;
    this.history = history;
  }

  public Literal getLiteral()
  {
    return(this.query);
  }

  public Answer getLocalAnswer()
  {
    return(this.localAnswer);
  }

  public Collection getSupportingMappings()
  {
    return(this.suppMappingsSet);
  }

  public Collection getConflictingMappings()
  {
    return(this.conflMappingsSet);
  }

  public Collection getHistory()
  {
    return(this.history);
  }

}
