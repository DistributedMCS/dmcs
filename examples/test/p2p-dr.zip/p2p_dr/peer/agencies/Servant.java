package agencies;

public interface Servant
{
  public void serve();
}
