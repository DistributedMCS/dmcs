package agencies;

import logic.*;
import knowledge.*;
import java.util.*;
import java.io.*;

public class TrustFileServant
implements Servant
{
  private String filename;
  private KnowledgeBase kb;

  public TrustFileServant(String filename)
  {
    this.filename = new String(filename);
  }

  public void serve()
  {
    BufferedReader br;
	ArrayList trustOrder;
	KnowledgeBase kb;
	String processedLine;

    try
    {
	  kb = KnowledgeBase.getInstance();
	  br = new BufferedReader(new InputStreamReader(new FileInputStream(this.filename)));
	  trustOrder = new ArrayList();

	  while(br.ready())
	  {
		processedLine = br.readLine();
		if(processedLine.length()>2)
		{
			//System.out.println("--" + processedLine);
			trustOrder.add(processedLine);
		}
	  }
	
	  kb.setTrustOrder(trustOrder);
   }
   catch(Throwable t)
   {
     t.printStackTrace();
   }
  }

}
