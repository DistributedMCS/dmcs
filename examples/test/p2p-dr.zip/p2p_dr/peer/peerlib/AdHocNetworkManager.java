/*
P2P_DR implementation in Java: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Evaluation: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Algorithm specification: Antonis Bikakis( bikakis@ics.forth.gr ) and Grigoris Antoniou ( antoniou@ics.forth.gr )
*/

package peerlib;

import network.*;
import network.listeners.*;
import peerlib.messages.*;
import peerlib.listeners.*;
import agencies.*;

public class AdHocNetworkManager
implements NetworkManager
{
  private static AdHocNetworkManager instance = null;
  private String nameServerAddress;
  private int listenPort;
  private static final int nameServerPort = 1030;
  private ThreadedListener respListener;
  private Thread thr;

  public AdHocNetworkManager(String nameServerAddress, int listenPort, int algorithm)
  throws Throwable
  {
    this.listenPort = listenPort;
    	
	respListener = new ResponseListener(listenPort, algorithm);
	thr = new Thread(respListener);
	thr.start();

	this.nameServerAddress = new String(nameServerAddress);
  }

  public AdHocNetworkManager(String nameServerAddress)
  throws Throwable
  {
    this.nameServerAddress = new String(nameServerAddress);
  }

  public AdHocNetworkManager()
  {
    this.nameServerAddress = null;
  }

  public void setNameServer(String nameServerAddress)
  {
    this.nameServerAddress = new String(nameServerAddress);
  }

  public static AdHocNetworkManager getInstance(String nameServerAddress)
  throws Throwable
  {
    if(instance == null)
      instance = new AdHocNetworkManager(nameServerAddress);
  
    return(instance);
  }

  public static AdHocNetworkManager getInstance(String nameServerAddress, int listenPort, int algorithm)
  throws Throwable
  {
    if(instance == null)
      instance = new AdHocNetworkManager(nameServerAddress, listenPort, algorithm);
  
    return(instance);
  }

  public void add(String peerName, String groupName)
  throws Throwable  
  {
    Pipe pipe;

    pipe = new Pipe(nameServerAddress, nameServerPort);
    pipe.writeToStream(new EnrollGroupMessage(peerName, groupName, this.listenPort));
    pipe = null;
  }

  public FindPeerResponse findPeer(String peerName, String peerGroupName)
  throws Throwable
  {
    Message respMsg;
    Pipe pipe;

    pipe = new Pipe(nameServerAddress, nameServerPort);
    pipe.writeToStream(new FindPeerMessage(peerName, peerGroupName));
    respMsg = (Message) pipe.readFromStream();

    if(respMsg instanceof ErrorMessage)
	throw new PeerConnectionException(((ErrorMessage)respMsg).getErrorMessage());

    pipe = null;

    return((FindPeerResponse)respMsg);
  }

}
  
