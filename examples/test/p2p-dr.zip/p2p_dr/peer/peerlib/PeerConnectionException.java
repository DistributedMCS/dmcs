package peerlib;

public class PeerConnectionException
extends Exception
{
  public PeerConnectionException()
  {
    super("PeerConnectionException");
  }
	
  public PeerConnectionException(String message)
  {
    super(message);
  }	
}
