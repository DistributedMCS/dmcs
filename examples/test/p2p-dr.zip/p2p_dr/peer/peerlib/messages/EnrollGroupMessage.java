package peerlib.messages;

public class EnrollGroupMessage
implements Message
{
  private String peerName;
  private String peerGroupName;
  private int port;

  public EnrollGroupMessage(String peerName, String peerGroupName, int port)
  {
    this.peerName = new String(peerName);
    this.peerGroupName = new String(peerGroupName);
	this.port = port;
  }

  public String getPeerName()
  {
    return(new String(this.peerName));
  }

  public String getPeerGroupName()
  {
    return(new String(this.peerGroupName));
  }

  public int getPort()
  {
	return(this.port);
  }
}
