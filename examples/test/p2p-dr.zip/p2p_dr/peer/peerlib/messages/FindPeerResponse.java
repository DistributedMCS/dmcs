package peerlib.messages;

public class FindPeerResponse
implements Message
{
  private String IPAddress;
  private int listenPort;

  public FindPeerResponse(String IPAddress, int listenPort)
  {
	this.listenPort = listenPort;
    this.IPAddress = IPAddress;
  }

  public String getIPAddress()
  {
    return(new String(this.IPAddress));
  }

  public int getPort()
  {
    return(this.listenPort);
  }
}
