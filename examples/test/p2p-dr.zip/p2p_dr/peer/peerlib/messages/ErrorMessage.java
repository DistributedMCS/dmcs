package peerlib.messages;

public class ErrorMessage
implements Message
{
  private String errorMsg;
  
  public ErrorMessage(String errorMsg)
  {
    this.errorMsg = new String(errorMsg);
  }

  public String getErrorMessage()
  {
    return(new String(this.errorMsg));
  }

}
