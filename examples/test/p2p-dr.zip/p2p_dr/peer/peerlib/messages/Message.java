package peerlib.messages;

import java.io.*;

public interface Message
extends Serializable
{}
