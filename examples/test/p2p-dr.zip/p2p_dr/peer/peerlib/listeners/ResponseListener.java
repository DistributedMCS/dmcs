package peerlib.listeners;

import java.net.Socket;
import network.listeners.*;
import peerlib.handlers.*;
import agencies.*;

public class ResponseListener
extends ThreadedListener
{
	protected int qs;

	public ResponseListener(int port, int qs)
	throws Throwable
	{
		super(port);
		this.qs = qs;
	}

	public void manageConnection(Socket socket)
	throws Throwable
	{
		ResponseHandler respHandler;

		respHandler = new ResponseHandler(socket, this.qs);
		respHandler.start();
	}
}