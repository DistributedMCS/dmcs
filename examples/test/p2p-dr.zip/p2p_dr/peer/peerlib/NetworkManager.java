package peerlib;

import peerlib.messages.*;

public interface NetworkManager
{
  public void add(String peerName, String groupName) throws Throwable;
  public FindPeerResponse findPeer(String peerName, String peerGroupName) throws Throwable;
}
  
