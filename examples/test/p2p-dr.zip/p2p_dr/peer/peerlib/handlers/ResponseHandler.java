package peerlib.handlers;

import network.*;
import java.net.Socket;
import peerlib.Peer;
import agencies.*;

public class ResponseHandler
extends Connector{

 protected int qs;
 protected QueryServant q;

	public ResponseHandler(Socket socket, int qs)
	{
		super(socket);
		this.qs = qs;
	}

	public void run()
	{
		Peer outcomingPeer;
		Thread thr;

		try
		{
			outcomingPeer = new Peer(socket);

			switch(this.qs)
			{
			  case 1   : q = new QueryServantSimpleAnswers(); break;
			  case 2   : q = new QueryServantPropSets(); break;
			  case 3   : q = new QueryServantComplexSets(); break;
			  case 4   : q = new QueryServantStrengthOfAnswers(); break;
			  default  : System.exit(1); break;
			}

			this.q.setParameters(outcomingPeer, "127.0.0.1", "group");			
			thr = new Thread((Runnable)this.q);
			thr.start();
		}
		catch(Throwable t)
		{
			System.out.println("Error in peerlib.ResponseHandler");
			t.printStackTrace();
		}
	}
}
