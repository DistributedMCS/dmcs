package peerlib;

import network.*;
import java.net.*;

public class Peer
{
  private Pipe peerPipe;
  private String peerName;
  //private static final int peersListenPort = 1030;

  public Peer(String peerName, String IPAddress, int port)
  throws Throwable
  {
    this.peerName = new String(peerName);
    this.peerPipe = new Pipe(IPAddress, port);
  }

  public Peer(Socket socket)
  throws Throwable
  {
    this.peerPipe = new Pipe(socket);
    this.peerName = null;
  }

  public int getPort()
  {
	return(this.peerPipe.getPort());
  }

  public int getLocalPort()
  {
	return(this.peerPipe.getLocalPort());
  }

  
  public void send(Object o)
  throws Throwable
  {
    this.peerPipe.writeToStream(o); // the MEssage not just the o
  }

  public Object receive()
  throws Throwable
  {
    return(this.peerPipe.readFromStream()); // the MEssage not just the o
  }

}
  
