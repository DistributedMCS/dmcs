package network;

import java.net.Socket;

public abstract class Connector
extends Thread
{
	protected Socket socket;

	public Connector(Socket socket)
	{
		this.socket = socket;
	}
}
