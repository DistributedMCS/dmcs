package network.listeners;

import java.io.IOException;

public abstract class ThreadedListener
extends Listener
implements Runnable
{
	public ThreadedListener(int port)
	throws IOException
	{
		super(port);
		this.port = port;
	}

	public void run()
	{
		this.waitForConnections();
	}
}
