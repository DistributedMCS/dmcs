package network.listeners;

import java.net.Socket;
import java.io.IOException;

public class ConnectionListener
extends Listener
{
	public ConnectionListener(int port)
	throws IOException
	{
		super(port);
	}

	public void manageConnection(Socket socket)
	{
	}
}
