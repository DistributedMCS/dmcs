/*
P2P_DR implementation in Java: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Evaluation: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Algorithm specification: Antonis Bikakis( bikakis@ics.forth.gr ) and Grigoris Antoniou ( antoniou@ics.forth.gr )
*/

package knowledge;

import logic.*;
import java.util.*;

// Singleton class
public class QueriesCache
{
  private static QueriesCache instance = null;
  protected Hashtable storage;

  public void rememberLiteral(Literal literal, Answer answer, Collection set)
  {
	AnswerSet as;

	as = new AnswerSet(answer, set);
	storage.put(literal.getSignWithName(), as);
  }

  public AnswerSet getAnswerForLiteral(Literal literal)
  {

	return((AnswerSet)storage.get(literal.getSignWithName()));

  }

}
