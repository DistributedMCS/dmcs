
/*
P2P_DR implementation in Java: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Evaluation: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Algorithm specification: Antonis Bikakis( bikakis@ics.forth.gr ) and Grigoris Antoniou ( antoniou@ics.forth.gr )
*/
package knowledge;

import logic.*;
import java.util.*;

public class AnswerSet
{
	private Answer answer = null;
	private Collection c = null;

	public AnswerSet(Answer answer, Collection c)
	{
		this.answer = answer;
		this.c = c;
	}

	public Collection getSet()
	{
		return(this.c);
	}

	public Answer getAnswer()
	{
		return(this.answer);
	}
}
