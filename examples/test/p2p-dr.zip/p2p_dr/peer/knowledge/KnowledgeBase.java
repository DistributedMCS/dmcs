/*
P2P_DR implementation in Java: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Evaluation: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Algorithm specification: Antonis Bikakis( bikakis@ics.forth.gr ) and Grigoris Antoniou ( antoniou@ics.forth.gr )
*/

package knowledge;

import logic.*;
import java.util.*;

// Singleton class
public class KnowledgeBase
implements KnowledgeBaseInterface
{
  private static KnowledgeBase instance = null;
  public static final String localSetName = "L";
  public static final String remoteSetName = "M";
  
  private Hashtable knowledgeSet;
  private ArrayList trustOrder;
  private ArrayList localLiteralList;

  public KnowledgeBase()
  {
    knowledgeSet = new Hashtable();
	localLiteralList = new ArrayList();
  }

  public static KnowledgeBase getInstance()
  throws Throwable
  {
    Class loadedClass;

    if(instance == null)
    {
      loadedClass   = Class.forName("knowledge.KnowledgeBase");
      instance = (KnowledgeBase) loadedClass.newInstance();
    }

    return(instance);
  }

  public void setTrustOrder(Collection c)
  {
	this.trustOrder = new ArrayList();
	this.trustOrder.addAll(c);
	//System.out.println(this.trustOrder.size());
  }

  public ArrayList getTrustOrder()
  {
	return(this.trustOrder);
  }

  
  public void createNewSet(String setName)
  throws Throwable
  {
    Hashtable h;    

	h = (Hashtable) knowledgeSet.get(setName);

	if(h!=null)
	  throw new ExistingSetException();

	knowledgeSet.put(setName, new Hashtable());
  }

  public void print()
  {
	Iterator iter;
	Literal literal;

	iter = localLiteralList.iterator();

	while(iter.hasNext())
	{
		literal = (Literal) iter.next();
		System.out.println(literal);
	}
  }

  public void addLocalLiteral(Literal literal)
  {
	if(isLocalLiteralInside(literal)==false)
		localLiteralList.add(literal);
  }

  public boolean isLocalLiteralInside(Literal l)
  {
	Iterator iter;
	Literal literal;

	iter = localLiteralList.iterator();

	while(iter.hasNext())
	{
		literal = (Literal) iter.next();
		//System.out.println(literal.getName());
		if( (literal.getName()).equals(l.getName()) && (literal.getSign() == l.getSign()) ){
		//System.out.println(literal.getName());
			return(true);
		}
	}

	return(false);
  }

  public void addRule(String setName, Rule rule)
  throws Throwable
  {
   	Hashtable h;
	Rule storedRule;
	LinkedList rules;

    	h = (Hashtable) knowledgeSet.get(setName);
	rules = (LinkedList) h.get(rule.getHeadName());

	if(rules!=null)
	{
		storedRule = (Rule) rules.getFirst();
		rules.addFirst(rule);
		h.put(rule.getHeadName(), rules);
	}
	else
	{
		rules = new LinkedList();
		rules.addFirst(rule);
		h.put(rule.getHeadName(), rules);
	}
  }

  public Collection getSupportingRulesByHeadLiteral(Literal l)
  throws Throwable
  {
	Collection setA, setB;
	LinkedList r, rules;
	Rule rule;
	Iterator iter;
	Literal literal;

	setA = getRulesByHeadLiteral(localSetName, l);
	setB = getRulesByHeadLiteral(remoteSetName, l);

	uniteSets(setA, setB);

	iter = setA.iterator();
	rules = new LinkedList();

    while(iter.hasNext())
	{
	  rule = (Rule) iter.next();
	  literal = rule.getHead();
      if(literal.getSign()==l.getSign())
	  {
		//	System.out.println(" ___" + literal.getSignWithName());
			rules.add(rule);
	  }
	}
	
	return(rules);
  }

  public Collection getConflictingRulesByHeadLiteral(Literal l)
  throws Throwable
  {
	Collection setA, setB;
	Hashtable h;
	LinkedList r, rules;
	Rule rule;
	Iterator iter;
	Literal literal;

	setA = getRulesByHeadLiteral(localSetName, l);
	setB = getRulesByHeadLiteral(remoteSetName, l);

	uniteSets(setA, setB);

	iter = setA.iterator();
	rules = new LinkedList();
  
	while(iter.hasNext())
	{
	  rule = (Rule) iter.next();
	  literal = rule.getHead();
      if(literal.getSign()!=l.getSign())
	  {
		//System.out.println(" ___" + literal.getSignWithName());
		rules.add(rule);
	  }
	}

	return(rules);
  }

  public Collection getRulesByHeadLiteral(String setName, Literal l)
  throws Throwable
  {
	Hashtable h;
	Rule storedRule;
	LinkedList rules;
	Iterator r;

	h = (Hashtable) knowledgeSet.get(setName);
	rules = (LinkedList) h.get(l.getName());

	if(rules == null)
	  return(new LinkedList());

	return(rules);
  }

  public boolean isRuleInside(String setName, Literal l)
  {
    Hashtable h;
	LinkedList rules;
 	Rule storedRule;

	h = (Hashtable) knowledgeSet.get(setName);
	rules = (LinkedList) h.get(l.getName());

	if(rules == null)
		return(false);

    storedRule = (Rule) rules.getFirst();

	if((storedRule.getHead()).getSign()==l.getSign())
		return(true);
	else
		return(false);

  }

  // SetA is the augmented one
  public void uniteSets(Collection setA, Collection setB)
  {
    Iterator iter;

    iter = setB.iterator();

    while(iter.hasNext())
      setA.add(iter.next());

  }

}
