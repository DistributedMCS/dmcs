/*
P2P_DR implementation in Java: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Evaluation: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Algorithm specification: Antonis Bikakis( bikakis@ics.forth.gr ) and Grigoris Antoniou ( antoniou@ics.forth.gr )
*/

package knowledge;

import logic.*;
import java.util.*;

// Singleton class
public class OutQueriesCache
extends QueriesCache
{
  private static OutQueriesCache instance = null;

  public OutQueriesCache()
  {
    super.storage = new Hashtable();
  }

  public static OutQueriesCache getInstance()
  throws Throwable
  {
    Class loadedClass;

    if(instance == null)
    {
      loadedClass = Class.forName("knowledge.OutQueriesCache");
      instance = (OutQueriesCache) loadedClass.newInstance();
    }

    return(instance);
  }

}
