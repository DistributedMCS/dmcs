package knowledge;

public class UnknownRuleException
extends Exception
{
  public UnknownRuleException()
  {
    super("UnknownRuleException");
  }
	
  public UnknownRuleException(String message)
  {
    super(message);
  }	
}
