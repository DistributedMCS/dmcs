/*
P2P_DR implementation in Java: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Evaluation: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Algorithm specification: Antonis Bikakis( bikakis@ics.forth.gr ) and Grigoris Antoniou ( antoniou@ics.forth.gr )
*/

package knowledge;

public class ExistingSetException
extends Exception
{
  public ExistingSetException()
  {
    super("ExistingSetException");
  }
	
  public ExistingSetException(String message)
  {
    super(message);
  }	
}
