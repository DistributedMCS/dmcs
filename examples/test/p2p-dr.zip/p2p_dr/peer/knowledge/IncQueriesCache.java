
/*
P2P_DR implementation in Java: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Evaluation: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Algorithm specification: Antonis Bikakis( bikakis@ics.forth.gr ) and Grigoris Antoniou ( antoniou@ics.forth.gr )
*/

package knowledge;

import logic.*;
import java.util.*;

// Singleton class
public class IncQueriesCache
extends QueriesCache
{
  private static IncQueriesCache instance = null;

  public IncQueriesCache()
  {
    super.storage = new Hashtable();
  }

  public static IncQueriesCache getInstance()
  throws Throwable
  {
    Class loadedClass;

    if(instance == null)
    {
      loadedClass = Class.forName("knowledge.IncQueriesCache");
      instance = (IncQueriesCache) loadedClass.newInstance();
    }

    return(instance);
  }

}
