/*
P2P_DR implementation in Java: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Evaluation: Panayiotis Hassapis ( chasapis@aueb.gr ) , Antonis Bikakis ( bikakis@ics.forth.gr )

Algorithm specification: Antonis Bikakis( bikakis@ics.forth.gr ) and Grigoris Antoniou ( antoniou@ics.forth.gr )
*/
import peerlib.*;
import knowledge.*;
import agencies.*;

public class Node
{
  private static final int sleepInterval = 5000;
  private static final String groupName = "group";

  public static void main(String[] args)
  {
    FileServant knowledgeFileServant;
    TrustFileServant trustFileServant;
    AdHocNetworkManager adhoc;
    KnowledgeBase kb;

   try
   {
    kb = KnowledgeBase.getInstance();
    kb.createNewSet(KnowledgeBase.localSetName); // set for local rules
    kb.createNewSet(KnowledgeBase.remoteSetName); // set for mapping rules

    knowledgeFileServant = new FileServant(args[0]+"_rules.txt");
    knowledgeFileServant.serve();

    trustFileServant = new TrustFileServant(args[0]+"_trust.txt");
    trustFileServant.serve();

    adhoc = AdHocNetworkManager.getInstance(args[2], Integer.parseInt(args[1]), Integer.parseInt(args[3]));
    adhoc.add(args[0], groupName); //peer , group

	System.out.println("\n");

   }
   catch(Throwable t)
   {
     t.printStackTrace();
   }
  }
}
